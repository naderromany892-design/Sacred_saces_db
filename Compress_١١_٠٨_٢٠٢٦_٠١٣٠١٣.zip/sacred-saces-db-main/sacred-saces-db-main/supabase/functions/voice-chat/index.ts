const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { question, churches, currentDate, currentTime } = await req.json();
    if (!question || typeof question !== "string") {
      return new Response(JSON.stringify({ error: "question is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      return new Response(JSON.stringify({ error: "AI not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const systemPrompt = `أنت "مساعد الكنيسة"، مساعد ذكي لكنيسة قبطية أرثوذكسية.
مهمتك تجاوب على أسئلة الشعب والخدام عن مواعيد الأنشطة.

قواعد أسلوب الكلام (مهمة جدًا):
1. ممنوع تقول كلمة "ابونا" لوحدها. قول "قدس ابونا فلان".
2. ممنوع تقول "خدام" لوحدها. قول "الخادم" للمفرد و"الخدام" للجمع.
3. كن سلس وبسيط: الرد قصير ومباشر بالعامية المصرية، من غير كلام رسمي زيادة.

المعرفة والوقت:
- النهاردة هو ${currentDate ?? "غير معروف"} الساعة ${currentTime ?? "غير معروف"}.
- "انهارده" = ${currentDate ?? "اليوم الحالي"}.
- "بكره" = اليوم الحالي + يوم واحد، احسبها تلقائي.

مصدر بياناتك: بيانات الأنشطة المرفقة فقط (church_name, activity_type, day, time, end_time, location).
ممنوع تخترع أي معاد. لو ملقتش المعلومة قول بالظبط: "مش عندي المعلومة دي حاليا بس اقدر اتأكدلك".

لو السؤال عن كنيسة معينة، جاوب ثم قل "هوديك لصفحة الكنيسة دلوقتي" وحدد churchId.

أجب دائمًا بصيغة JSON فقط بالشكل:
{"answer":"نص الرد","churchId":"معرف الكنيسة أو null"}

بيانات الكنائس والأنشطة:
${JSON.stringify(churches ?? []).slice(0, 60000)}`;

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: question },
        ],
        response_format: { type: "json_object" },
      }),
    });

    if (!res.ok) {
      const text = await res.text().catch(() => "");
      return new Response(JSON.stringify({ error: text || "AI request failed" }), {
        status: res.status,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await res.json();
    const content: string = data?.choices?.[0]?.message?.content ?? "{}";
    let parsed: { answer?: string; churchId?: string | null } = {};
    try {
      parsed = JSON.parse(content);
    } catch {
      parsed = { answer: content };
    }

    return new Response(
      JSON.stringify({
        answer: parsed.answer || "مش عندي المعلومة دي حاليا بس اقدر اتأكدلك",
        churchId: parsed.churchId && parsed.churchId !== "null" ? parsed.churchId : null,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
