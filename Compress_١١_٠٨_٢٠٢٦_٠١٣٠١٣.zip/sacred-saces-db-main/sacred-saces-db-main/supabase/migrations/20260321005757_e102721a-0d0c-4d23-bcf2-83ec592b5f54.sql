
-- Create admin_code table for storing the admin secret code
CREATE TABLE IF NOT EXISTS public.admin_code (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code_hash text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.admin_code ENABLE ROW LEVEL SECURITY;

-- Allow anyone to read (needed for verification via RPC)
-- No direct access policies - all access through RPC

-- Function to verify admin code (no auth required)
CREATE OR REPLACE FUNCTION public.verify_admin_code(_code text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE _hash text;
BEGIN
  SELECT code_hash INTO _hash FROM admin_code LIMIT 1;
  IF _hash IS NULL THEN RETURN false; END IF;
  RETURN _hash = crypt(_code, _hash);
END;
$$;

-- Function to change admin code (requires current code)
CREATE OR REPLACE FUNCTION public.change_admin_code(_current_code text, _new_code text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NOT verify_admin_code(_current_code) THEN
    RETURN false;
  END IF;
  IF EXISTS (SELECT 1 FROM admin_code) THEN
    UPDATE admin_code SET code_hash = crypt(_new_code, gen_salt('bf')), updated_at = now();
  ELSE
    INSERT INTO admin_code (code_hash) VALUES (crypt(_new_code, gen_salt('bf')));
  END IF;
  RETURN true;
END;
$$;

-- Insert the initial admin code: 0122131
INSERT INTO admin_code (code_hash) VALUES (crypt('0122131', gen_salt('bf')));

-- Update supervisor functions to also accept admin code
CREATE OR REPLACE FUNCTION public.verify_supervisor_password(_password text, _church_id uuid DEFAULT NULL)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _mode text;
  _hash text;
BEGIN
  -- First check if it's the admin code
  IF verify_admin_code(_password) THEN RETURN true; END IF;
  
  SELECT password_mode INTO _mode FROM supervisor_config LIMIT 1;
  _mode := COALESCE(_mode, 'global');
  
  IF _mode = 'global' THEN
    SELECT global_password_hash INTO _hash FROM supervisor_config LIMIT 1;
    IF _hash IS NULL THEN RETURN false; END IF;
    RETURN _hash = crypt(_password, _hash);
  ELSE
    IF _church_id IS NULL THEN RETURN false; END IF;
    SELECT password_hash INTO _hash FROM church_passwords WHERE church_id = _church_id;
    IF _hash IS NULL THEN RETURN false; END IF;
    RETURN _hash = crypt(_password, _hash);
  END IF;
END;
$$;

-- Admin versions of set functions that use admin code instead of auth
CREATE OR REPLACE FUNCTION public.admin_set_global_password(_admin_code text, _password text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NOT verify_admin_code(_admin_code) THEN RETURN false; END IF;
  IF EXISTS (SELECT 1 FROM supervisor_config) THEN
    UPDATE supervisor_config SET global_password_hash = crypt(_password, gen_salt('bf')), updated_at = now();
  ELSE
    INSERT INTO supervisor_config (global_password_hash) VALUES (crypt(_password, gen_salt('bf')));
  END IF;
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_set_church_password(_admin_code text, _church_id uuid, _password text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NOT verify_admin_code(_admin_code) THEN RETURN false; END IF;
  INSERT INTO church_passwords (church_id, password_hash)
  VALUES (_church_id, crypt(_password, gen_salt('bf')))
  ON CONFLICT (church_id)
  DO UPDATE SET password_hash = crypt(_password, gen_salt('bf')), updated_at = now();
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_set_password_mode(_admin_code text, _mode text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NOT verify_admin_code(_admin_code) THEN RETURN false; END IF;
  IF NOT _mode IN ('global', 'per_church') THEN RETURN false; END IF;
  IF EXISTS (SELECT 1 FROM supervisor_config) THEN
    UPDATE supervisor_config SET password_mode = _mode, updated_at = now();
  ELSE
    INSERT INTO supervisor_config (password_mode) VALUES (_mode);
  END IF;
  RETURN true;
END;
$$;

-- Admin donation management functions
CREATE OR REPLACE FUNCTION public.admin_add_donation(_admin_code text, _section text, _payment_method text, _label text, _details text, _sort_order int DEFAULT 0)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE _id uuid;
BEGIN
  IF NOT verify_admin_code(_admin_code) THEN RAISE EXCEPTION 'كود خاطئ'; END IF;
  INSERT INTO donation_settings (section, payment_method, label, details, sort_order)
  VALUES (_section, _payment_method, _label, _details, _sort_order)
  RETURNING id INTO _id;
  RETURN _id;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_delete_donation(_admin_code text, _donation_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NOT verify_admin_code(_admin_code) THEN RETURN false; END IF;
  DELETE FROM donation_settings WHERE id = _donation_id;
  RETURN true;
END;
$$;

-- Admin activity management (add as approved directly)
CREATE OR REPLACE FUNCTION public.admin_add_activity(_admin_code text, _church_id uuid, _day text, _activity_type text, _time text, _sort_time text, _location text DEFAULT '')
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE _new_id uuid;
BEGIN
  IF NOT verify_admin_code(_admin_code) THEN RAISE EXCEPTION 'كود خاطئ'; END IF;
  INSERT INTO activities (church_id, day, activity_type, time, sort_time, location, created_by, status)
  VALUES (_church_id, _day, _activity_type, _time, _sort_time, _location, '00000000-0000-0000-0000-000000000000', 'approved')
  RETURNING id INTO _new_id;
  RETURN _new_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_delete_activity(_admin_code text, _activity_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NOT verify_admin_code(_admin_code) THEN RETURN false; END IF;
  DELETE FROM activities WHERE id = _activity_id;
  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_approve_activity(_admin_code text, _activity_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NOT verify_admin_code(_admin_code) THEN RETURN false; END IF;
  UPDATE activities SET status = 'approved', updated_at = now() WHERE id = _activity_id;
  RETURN true;
END;
$$;

-- Get all activities for a church (admin version, no auth needed)
CREATE OR REPLACE FUNCTION public.admin_get_activities(_admin_code text, _church_id uuid)
RETURNS TABLE(act_id uuid, act_day text, act_type text, act_time text, act_sort_time text, act_location text, act_status text, act_confirmations integer, act_needed integer, act_created_at timestamptz)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NOT verify_admin_code(_admin_code) THEN RAISE EXCEPTION 'كود خاطئ'; END IF;
  RETURN QUERY SELECT a.id, a.day, a.activity_type, a.time, a.sort_time, a.location, a.status,
    a.current_confirmations, a.confirmations_needed, a.created_at
  FROM activities a WHERE a.church_id = _church_id ORDER BY a.sort_time;
END;
$$;
