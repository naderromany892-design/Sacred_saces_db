CREATE TABLE public.available_activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  activity_name text NOT NULL UNIQUE,
  icon text NOT NULL DEFAULT '🙏',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.available_activities TO anon, authenticated;
GRANT ALL ON public.available_activities TO service_role;
ALTER TABLE public.available_activities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "available_activities_public_read" ON public.available_activities FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.activity_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  church_id text NOT NULL,
  church_name text NOT NULL,
  governorate text NOT NULL,
  activity_id uuid NOT NULL REFERENCES public.available_activities(id) ON DELETE CASCADE,
  device_id text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (church_id, activity_id, device_id)
);
GRANT SELECT, INSERT ON public.activity_requests TO anon, authenticated;
GRANT ALL ON public.activity_requests TO service_role;
ALTER TABLE public.activity_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "activity_requests_public_read" ON public.activity_requests FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "activity_requests_public_insert" ON public.activity_requests FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE TRIGGER update_available_activities_updated_at BEFORE UPDATE ON public.available_activities FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.available_activities (activity_name, icon) VALUES
  ('اجتماع شباب', '👥'),
  ('لعب كورة', '⚽'),
  ('قداس', '⛪'),
  ('تسبحة', '🎶'),
  ('قداس ليلي', '🌙');