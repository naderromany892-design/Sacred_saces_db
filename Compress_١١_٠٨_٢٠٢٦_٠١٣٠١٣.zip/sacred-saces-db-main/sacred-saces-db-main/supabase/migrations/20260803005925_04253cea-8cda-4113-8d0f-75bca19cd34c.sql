CREATE OR REPLACE FUNCTION public.confirm_activity(_activity_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  _count INTEGER;
  _needed INTEGER;
  _church uuid;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;

  SELECT church_id, confirmations_needed INTO _church, _needed
  FROM public.activities WHERE id = _activity_id;

  IF _church IS NULL THEN
    RAISE EXCEPTION 'النشاط غير موجود';
  END IF;

  IF NOT (
    public.has_role(auth.uid(), 'admin')
    OR _church IN (SELECT public.get_supervisor_church_ids(auth.uid()))
  ) THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;

  INSERT INTO public.activity_confirmations (activity_id, confirmed_by)
  VALUES (_activity_id, auth.uid())
  ON CONFLICT (activity_id, confirmed_by) DO NOTHING;

  SELECT COUNT(*) INTO _count FROM public.activity_confirmations WHERE activity_id = _activity_id;

  UPDATE public.activities
  SET current_confirmations = _count,
      status = CASE WHEN _count >= _needed THEN 'approved' ELSE status END,
      updated_at = now()
  WHERE id = _activity_id;
END;
$function$;

REVOKE ALL ON TABLE public.admin_code FROM anon, authenticated;
REVOKE ALL ON TABLE public.church_passwords FROM anon, authenticated;
REVOKE ALL ON TABLE public.supervisor_config FROM anon, authenticated;
REVOKE ALL ON TABLE public.user_roles FROM anon;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER ON TABLE public.user_roles FROM authenticated;
GRANT SELECT ON TABLE public.user_roles TO authenticated;
REVOKE ALL ON TABLE public.profiles FROM anon;
GRANT SELECT, INSERT, UPDATE ON TABLE public.profiles TO authenticated;