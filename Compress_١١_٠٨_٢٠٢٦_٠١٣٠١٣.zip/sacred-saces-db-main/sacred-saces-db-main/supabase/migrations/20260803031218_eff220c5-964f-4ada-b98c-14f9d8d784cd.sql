GRANT INSERT, DELETE ON public.available_activities TO anon, authenticated;
CREATE POLICY "available_activities_app_insert" ON public.available_activities FOR INSERT TO anon, authenticated WITH CHECK (length(trim(activity_name)) BETWEEN 1 AND 60);
CREATE POLICY "available_activities_app_delete" ON public.available_activities FOR DELETE TO anon, authenticated USING (true);