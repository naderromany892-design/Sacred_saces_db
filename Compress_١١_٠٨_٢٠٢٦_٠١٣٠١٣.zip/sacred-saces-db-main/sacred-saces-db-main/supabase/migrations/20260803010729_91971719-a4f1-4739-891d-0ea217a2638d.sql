REVOKE ALL ON public.profiles FROM anon, authenticated, PUBLIC;
REVOKE ALL ON public.user_roles FROM anon, authenticated, PUBLIC;
REVOKE ALL ON public.activity_confirmations FROM anon, authenticated, PUBLIC;
GRANT ALL ON public.profiles TO service_role;
GRANT ALL ON public.user_roles TO service_role;
GRANT ALL ON public.activity_confirmations TO service_role;

REVOKE ALL ON public.churches FROM anon, authenticated, PUBLIC;
REVOKE ALL ON public.donation_settings FROM anon, authenticated, PUBLIC;
REVOKE ALL ON public.activities FROM anon, authenticated, PUBLIC;
REVOKE ALL ON public.prayer_times FROM anon, authenticated, PUBLIC;
REVOKE ALL ON public.fixed_masses FROM anon, authenticated, PUBLIC;

GRANT SELECT ON public.churches, public.donation_settings, public.activities, public.prayer_times, public.fixed_masses TO anon, authenticated;
GRANT ALL ON public.churches, public.donation_settings, public.activities, public.prayer_times, public.fixed_masses TO service_role;