
-- Create role enum
CREATE TYPE public.app_role AS ENUM ('admin', 'supervisor');

-- Create churches table
CREATE TABLE public.churches (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  governorate TEXT NOT NULL,
  city TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  image_url TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user_roles table
CREATE TABLE public.user_roles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  church_id UUID REFERENCES public.churches(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (user_id, role, church_id)
);

-- Create profiles table
CREATE TABLE public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  email TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create activities table with approval system
CREATE TABLE public.activities (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  church_id UUID NOT NULL REFERENCES public.churches(id) ON DELETE CASCADE,
  day TEXT NOT NULL CHECK (day IN ('السبت','الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة')),
  activity_type TEXT NOT NULL CHECK (activity_type IN ('قداس','اجتماع','تسبحة','خدمة','اجتماع شباب','مدارس الأحد')),
  time TEXT NOT NULL,
  sort_time TEXT NOT NULL,
  location TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  confirmations_needed INTEGER NOT NULL DEFAULT 2,
  current_confirmations INTEGER NOT NULL DEFAULT 0,
  created_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create activity_confirmations table
CREATE TABLE public.activity_confirmations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  activity_id UUID NOT NULL REFERENCES public.activities(id) ON DELETE CASCADE,
  confirmed_by UUID NOT NULL REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (activity_id, confirmed_by)
);

-- Create fixed_masses table
CREATE TABLE public.fixed_masses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  church_id UUID NOT NULL REFERENCES public.churches(id) ON DELETE CASCADE,
  label TEXT NOT NULL,
  time TEXT NOT NULL,
  days TEXT NOT NULL
);

-- Create prayer_times table
CREATE TABLE public.prayer_times (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  church_id UUID NOT NULL REFERENCES public.churches(id) ON DELETE CASCADE,
  label TEXT NOT NULL,
  time TEXT NOT NULL,
  days TEXT NOT NULL
);

-- Enable RLS on all tables
ALTER TABLE public.churches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activity_confirmations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fixed_masses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.prayer_times ENABLE ROW LEVEL SECURITY;

-- Security definer function to check roles
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- Function to get supervisor's church IDs
CREATE OR REPLACE FUNCTION public.get_supervisor_church_ids(_user_id UUID)
RETURNS SETOF UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT church_id FROM public.user_roles
  WHERE user_id = _user_id AND role = 'supervisor' AND church_id IS NOT NULL
$$;

-- Churches: public read, supervisors/admins can manage
CREATE POLICY "Anyone can view churches" ON public.churches FOR SELECT USING (true);
CREATE POLICY "Supervisors can insert churches" ON public.churches FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'supervisor') OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Supervisors can update their churches" ON public.churches FOR UPDATE USING (
  public.has_role(auth.uid(), 'admin') OR id IN (SELECT public.get_supervisor_church_ids(auth.uid()))
);

-- User roles
CREATE POLICY "Users can view their own roles" ON public.user_roles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Admins can insert roles" ON public.user_roles FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can update roles" ON public.user_roles FOR UPDATE USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins can delete roles" ON public.user_roles FOR DELETE USING (public.has_role(auth.uid(), 'admin'));

-- Profiles
CREATE POLICY "Users can view their own profile" ON public.profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING (auth.uid() = user_id);

-- Activities
CREATE POLICY "Anyone can view approved activities" ON public.activities FOR SELECT USING (
  status = 'approved' OR auth.uid() = created_by OR 
  church_id IN (SELECT public.get_supervisor_church_ids(auth.uid()))
);
CREATE POLICY "Supervisors can insert activities" ON public.activities FOR INSERT WITH CHECK (
  church_id IN (SELECT public.get_supervisor_church_ids(auth.uid()))
);
CREATE POLICY "Supervisors can update activities" ON public.activities FOR UPDATE USING (
  church_id IN (SELECT public.get_supervisor_church_ids(auth.uid()))
);
CREATE POLICY "Supervisors can delete activities" ON public.activities FOR DELETE USING (
  church_id IN (SELECT public.get_supervisor_church_ids(auth.uid()))
);

-- Activity confirmations
CREATE POLICY "Supervisors can view confirmations" ON public.activity_confirmations FOR SELECT USING (
  activity_id IN (
    SELECT a.id FROM public.activities a 
    WHERE a.church_id IN (SELECT public.get_supervisor_church_ids(auth.uid()))
  )
);
CREATE POLICY "Supervisors can confirm activities" ON public.activity_confirmations FOR INSERT WITH CHECK (
  auth.uid() = confirmed_by AND
  activity_id IN (
    SELECT a.id FROM public.activities a 
    WHERE a.church_id IN (SELECT public.get_supervisor_church_ids(auth.uid()))
  )
);

-- Fixed masses & prayer times: public read, supervisors manage
CREATE POLICY "Anyone can view fixed masses" ON public.fixed_masses FOR SELECT USING (true);
CREATE POLICY "Supervisors can manage fixed masses" ON public.fixed_masses FOR INSERT WITH CHECK (
  church_id IN (SELECT public.get_supervisor_church_ids(auth.uid())) OR public.has_role(auth.uid(), 'admin')
);
CREATE POLICY "Supervisors can update fixed masses" ON public.fixed_masses FOR UPDATE USING (
  church_id IN (SELECT public.get_supervisor_church_ids(auth.uid())) OR public.has_role(auth.uid(), 'admin')
);
CREATE POLICY "Supervisors can delete fixed masses" ON public.fixed_masses FOR DELETE USING (
  church_id IN (SELECT public.get_supervisor_church_ids(auth.uid())) OR public.has_role(auth.uid(), 'admin')
);
CREATE POLICY "Anyone can view prayer times" ON public.prayer_times FOR SELECT USING (true);
CREATE POLICY "Supervisors can manage prayer times" ON public.prayer_times FOR INSERT WITH CHECK (
  church_id IN (SELECT public.get_supervisor_church_ids(auth.uid())) OR public.has_role(auth.uid(), 'admin')
);
CREATE POLICY "Supervisors can update prayer times" ON public.prayer_times FOR UPDATE USING (
  church_id IN (SELECT public.get_supervisor_church_ids(auth.uid())) OR public.has_role(auth.uid(), 'admin')
);
CREATE POLICY "Supervisors can delete prayer times" ON public.prayer_times FOR DELETE USING (
  church_id IN (SELECT public.get_supervisor_church_ids(auth.uid())) OR public.has_role(auth.uid(), 'admin')
);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, email, display_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'display_name', NEW.email));
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to confirm activity and auto-approve when threshold met
CREATE OR REPLACE FUNCTION public.confirm_activity(_activity_id UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _count INTEGER;
  _needed INTEGER;
BEGIN
  INSERT INTO public.activity_confirmations (activity_id, confirmed_by)
  VALUES (_activity_id, auth.uid())
  ON CONFLICT (activity_id, confirmed_by) DO NOTHING;
  
  SELECT COUNT(*) INTO _count FROM public.activity_confirmations WHERE activity_id = _activity_id;
  SELECT confirmations_needed INTO _needed FROM public.activities WHERE id = _activity_id;
  
  UPDATE public.activities 
  SET current_confirmations = _count,
      status = CASE WHEN _count >= _needed THEN 'approved' ELSE status END,
      updated_at = now()
  WHERE id = _activity_id;
END;
$$;

-- Updated_at trigger
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_churches_updated_at BEFORE UPDATE ON public.churches FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_activities_updated_at BEFORE UPDATE ON public.activities FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
