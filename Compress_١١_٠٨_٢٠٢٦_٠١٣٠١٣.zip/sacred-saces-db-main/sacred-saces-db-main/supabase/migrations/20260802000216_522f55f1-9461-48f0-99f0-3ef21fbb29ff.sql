-- 1. Rotate the leaked hardcoded admin code to a random secret value
UPDATE public.admin_code SET code_hash = crypt(encode(gen_random_bytes(32), 'hex'), gen_salt('bf')), updated_at = now();
INSERT INTO public.admin_code (code_hash)
SELECT crypt(encode(gen_random_bytes(32), 'hex'), gen_salt('bf'))
WHERE NOT EXISTS (SELECT 1 FROM public.admin_code);

-- 2. Revoke EXECUTE on sensitive SECURITY DEFINER functions from public API roles
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prosecdef
  LOOP
    EXECUTE format('REVOKE ALL ON FUNCTION %s FROM PUBLIC, anon, authenticated', r.sig);
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO service_role', r.sig);
  END LOOP;
END $$;

-- 3. Hide sensitive tables from the exposed Data API / GraphQL schema
REVOKE ALL ON TABLE public.admin_code FROM anon, authenticated;
REVOKE ALL ON TABLE public.church_passwords FROM anon, authenticated;
REVOKE ALL ON TABLE public.supervisor_config FROM anon, authenticated;
REVOKE ALL ON TABLE public.user_roles FROM anon, authenticated;
REVOKE ALL ON TABLE public.profiles FROM anon, authenticated;

GRANT ALL ON TABLE public.admin_code TO service_role;
GRANT ALL ON TABLE public.church_passwords TO service_role;
GRANT ALL ON TABLE public.supervisor_config TO service_role;
GRANT ALL ON TABLE public.user_roles TO service_role;
GRANT ALL ON TABLE public.profiles TO service_role;