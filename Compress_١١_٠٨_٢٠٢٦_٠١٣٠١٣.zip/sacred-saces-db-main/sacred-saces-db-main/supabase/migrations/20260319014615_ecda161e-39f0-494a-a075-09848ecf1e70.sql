
-- Supervisor: list all activities for a church (including pending)
CREATE OR REPLACE FUNCTION public.supervisor_get_activities(_password text, _church_id uuid)
RETURNS TABLE(act_id uuid, act_day text, act_type text, act_time text, act_sort_time text, act_location text, act_status text, act_confirmations int, act_needed int, act_created_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT verify_supervisor_password(_password, _church_id) THEN
    RAISE EXCEPTION 'كلمة السر غير صحيحة';
  END IF;
  RETURN QUERY SELECT a.id, a.day, a.activity_type, a.time, a.sort_time, a.location, a.status,
    a.current_confirmations, a.confirmations_needed, a.created_at
  FROM activities a WHERE a.church_id = _church_id ORDER BY a.sort_time;
END;
$$;
