
-- Enable pgcrypto for password hashing
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- =============================================
-- 1. Supervisor Config (global password mode)
-- =============================================
CREATE TABLE IF NOT EXISTS public.supervisor_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  password_mode text NOT NULL DEFAULT 'global' CHECK (password_mode IN ('global', 'per_church')),
  global_password_hash text,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.supervisor_config ENABLE ROW LEVEL SECURITY;

-- Only admin can read/write supervisor_config
CREATE POLICY "Admins can manage supervisor_config" ON public.supervisor_config
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- =============================================
-- 2. Church Passwords (per-church mode)
-- =============================================
CREATE TABLE IF NOT EXISTS public.church_passwords (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  church_id uuid NOT NULL REFERENCES public.churches(id) ON DELETE CASCADE UNIQUE,
  password_hash text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.church_passwords ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can manage church_passwords" ON public.church_passwords
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- =============================================
-- 3. Donation Settings (admin-managed payment info)
-- =============================================
CREATE TABLE IF NOT EXISTS public.donation_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  section text NOT NULL CHECK (section IN ('churches', 'humanitarian', 'app')),
  payment_method text NOT NULL,
  label text NOT NULL,
  details text NOT NULL,
  sort_order int NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.donation_settings ENABLE ROW LEVEL SECURITY;

-- Anyone can view donation settings (public page)
CREATE POLICY "Anyone can view donation_settings" ON public.donation_settings
  FOR SELECT TO public USING (true);

-- Only admin can manage donation settings
CREATE POLICY "Admins can manage donation_settings" ON public.donation_settings
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- =============================================
-- 4. RPC: get_password_mode
-- =============================================
CREATE OR REPLACE FUNCTION public.get_password_mode()
RETURNS text
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _mode text;
BEGIN
  SELECT password_mode INTO _mode FROM supervisor_config LIMIT 1;
  RETURN COALESCE(_mode, 'global');
END;
$$;

-- =============================================
-- 5. RPC: set_password_mode (admin only)
-- =============================================
CREATE OR REPLACE FUNCTION public.set_password_mode(_mode text)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  IF NOT _mode IN ('global', 'per_church') THEN
    RAISE EXCEPTION 'وضع غير صالح';
  END IF;
  IF EXISTS (SELECT 1 FROM supervisor_config) THEN
    UPDATE supervisor_config SET password_mode = _mode, updated_at = now();
  ELSE
    INSERT INTO supervisor_config (password_mode) VALUES (_mode);
  END IF;
END;
$$;

-- =============================================
-- 6. RPC: set_global_password (admin only)
-- =============================================
CREATE OR REPLACE FUNCTION public.set_global_password(_password text)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  IF EXISTS (SELECT 1 FROM supervisor_config) THEN
    UPDATE supervisor_config SET global_password_hash = crypt(_password, gen_salt('bf')), updated_at = now();
  ELSE
    INSERT INTO supervisor_config (global_password_hash) VALUES (crypt(_password, gen_salt('bf')));
  END IF;
END;
$$;

-- =============================================
-- 7. RPC: set_church_password (admin only)
-- =============================================
CREATE OR REPLACE FUNCTION public.set_church_password(_church_id uuid, _password text)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'غير مصرح';
  END IF;
  INSERT INTO church_passwords (church_id, password_hash)
  VALUES (_church_id, crypt(_password, gen_salt('bf')))
  ON CONFLICT (church_id)
  DO UPDATE SET password_hash = crypt(_password, gen_salt('bf')), updated_at = now();
END;
$$;

-- =============================================
-- 8. RPC: verify_supervisor_password
-- =============================================
CREATE OR REPLACE FUNCTION public.verify_supervisor_password(_password text, _church_id uuid DEFAULT NULL)
RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _mode text;
  _hash text;
BEGIN
  SELECT password_mode INTO _mode FROM supervisor_config LIMIT 1;
  _mode := COALESCE(_mode, 'global');
  
  IF _mode = 'global' THEN
    SELECT global_password_hash INTO _hash FROM supervisor_config LIMIT 1;
    IF _hash IS NULL THEN RETURN false; END IF;
    RETURN _hash = crypt(_password, _hash);
  ELSE
    IF _church_id IS NULL THEN RETURN false; END IF;
    SELECT password_hash INTO _hash FROM church_passwords WHERE church_id = _church_id;
    IF _hash IS NULL THEN RETURN false; END IF;
    RETURN _hash = crypt(_password, _hash);
  END IF;
END;
$$;

-- =============================================
-- 9. RPC: supervisor_add_activity
-- =============================================
CREATE OR REPLACE FUNCTION public.supervisor_add_activity(
  _password text, _church_id uuid, _day text, _activity_type text,
  _time text, _sort_time text, _location text DEFAULT ''
)
RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _new_id uuid;
BEGIN
  IF NOT verify_supervisor_password(_password, _church_id) THEN
    RAISE EXCEPTION 'كلمة السر غير صحيحة';
  END IF;
  INSERT INTO activities (church_id, day, activity_type, time, sort_time, location, created_by, status)
  VALUES (_church_id, _day, _activity_type, _time, _sort_time, _location, '00000000-0000-0000-0000-000000000000', 'pending')
  RETURNING id INTO _new_id;
  RETURN _new_id;
END;
$$;

-- =============================================
-- 10. RPC: supervisor_approve_activity
-- =============================================
CREATE OR REPLACE FUNCTION public.supervisor_approve_activity(_password text, _activity_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _church uuid;
BEGIN
  SELECT church_id INTO _church FROM activities WHERE id = _activity_id;
  IF NOT verify_supervisor_password(_password, _church) THEN
    RAISE EXCEPTION 'كلمة السر غير صحيحة';
  END IF;
  UPDATE activities SET status = 'approved', updated_at = now() WHERE id = _activity_id;
END;
$$;

-- =============================================
-- 11. RPC: supervisor_delete_activity
-- =============================================
CREATE OR REPLACE FUNCTION public.supervisor_delete_activity(_password text, _activity_id uuid)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _church uuid;
BEGIN
  SELECT church_id INTO _church FROM activities WHERE id = _activity_id;
  IF NOT verify_supervisor_password(_password, _church) THEN
    RAISE EXCEPTION 'كلمة السر غير صحيحة';
  END IF;
  DELETE FROM activities WHERE id = _activity_id;
END;
$$;

-- Drop old supervisor_get_activities and recreate with correct signature
DROP FUNCTION IF EXISTS public.supervisor_get_activities(text, uuid);

CREATE OR REPLACE FUNCTION public.supervisor_get_activities(_password text, _church_id uuid)
RETURNS TABLE(act_id uuid, act_day text, act_type text, act_time text, act_sort_time text, act_location text, act_status text, act_confirmations int, act_needed int, act_created_at timestamptz)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT verify_supervisor_password(_password, _church_id) THEN
    RAISE EXCEPTION 'كلمة السر غير صحيحة';
  END IF;
  RETURN QUERY SELECT a.id, a.day, a.activity_type, a.time, a.sort_time, a.location, a.status,
    a.current_confirmations, a.confirmations_needed, a.created_at
  FROM activities a WHERE a.church_id = _church_id ORDER BY a.sort_time;
END;
$$;
