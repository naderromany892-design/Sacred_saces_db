export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.4"
  }
  public: {
    Tables: {
      activities: {
        Row: {
          activity_type: string
          church_id: string
          confirmations_needed: number
          created_at: string
          created_by: string
          current_confirmations: number
          day: string
          id: string
          location: string | null
          sort_time: string
          status: string
          time: string
          updated_at: string
        }
        Insert: {
          activity_type: string
          church_id: string
          confirmations_needed?: number
          created_at?: string
          created_by: string
          current_confirmations?: number
          day: string
          id?: string
          location?: string | null
          sort_time: string
          status?: string
          time: string
          updated_at?: string
        }
        Update: {
          activity_type?: string
          church_id?: string
          confirmations_needed?: number
          created_at?: string
          created_by?: string
          current_confirmations?: number
          day?: string
          id?: string
          location?: string | null
          sort_time?: string
          status?: string
          time?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "activities_church_id_fkey"
            columns: ["church_id"]
            isOneToOne: false
            referencedRelation: "churches"
            referencedColumns: ["id"]
          },
        ]
      }
      activity_confirmations: {
        Row: {
          activity_id: string
          confirmed_by: string
          created_at: string
          id: string
        }
        Insert: {
          activity_id: string
          confirmed_by: string
          created_at?: string
          id?: string
        }
        Update: {
          activity_id?: string
          confirmed_by?: string
          created_at?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "activity_confirmations_activity_id_fkey"
            columns: ["activity_id"]
            isOneToOne: false
            referencedRelation: "activities"
            referencedColumns: ["id"]
          },
        ]
      }
      activity_requests: {
        Row: {
          activity_id: string
          church_id: string
          church_name: string
          created_at: string
          device_id: string
          governorate: string
          id: string
        }
        Insert: {
          activity_id: string
          church_id: string
          church_name: string
          created_at?: string
          device_id: string
          governorate: string
          id?: string
        }
        Update: {
          activity_id?: string
          church_id?: string
          church_name?: string
          created_at?: string
          device_id?: string
          governorate?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "activity_requests_activity_id_fkey"
            columns: ["activity_id"]
            isOneToOne: false
            referencedRelation: "available_activities"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_code: {
        Row: {
          code_hash: string
          id: string
          updated_at: string
        }
        Insert: {
          code_hash: string
          id?: string
          updated_at?: string
        }
        Update: {
          code_hash?: string
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      available_activities: {
        Row: {
          activity_name: string
          created_at: string
          icon: string
          id: string
          updated_at: string
        }
        Insert: {
          activity_name: string
          created_at?: string
          icon?: string
          id?: string
          updated_at?: string
        }
        Update: {
          activity_name?: string
          created_at?: string
          icon?: string
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      church_passwords: {
        Row: {
          church_id: string
          id: string
          password_hash: string
          updated_at: string
        }
        Insert: {
          church_id: string
          id?: string
          password_hash: string
          updated_at?: string
        }
        Update: {
          church_id?: string
          id?: string
          password_hash?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "church_passwords_church_id_fkey"
            columns: ["church_id"]
            isOneToOne: true
            referencedRelation: "churches"
            referencedColumns: ["id"]
          },
        ]
      }
      churches: {
        Row: {
          address: string
          city: string
          created_at: string
          governorate: string
          id: string
          image_url: string
          name: string
          updated_at: string
        }
        Insert: {
          address?: string
          city?: string
          created_at?: string
          governorate: string
          id?: string
          image_url?: string
          name: string
          updated_at?: string
        }
        Update: {
          address?: string
          city?: string
          created_at?: string
          governorate?: string
          id?: string
          image_url?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      donation_settings: {
        Row: {
          details: string
          id: string
          label: string
          payment_method: string
          section: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          details: string
          id?: string
          label: string
          payment_method: string
          section: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          details?: string
          id?: string
          label?: string
          payment_method?: string
          section?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      fixed_masses: {
        Row: {
          church_id: string
          days: string
          id: string
          label: string
          time: string
        }
        Insert: {
          church_id: string
          days: string
          id?: string
          label: string
          time: string
        }
        Update: {
          church_id?: string
          days?: string
          id?: string
          label?: string
          time?: string
        }
        Relationships: [
          {
            foreignKeyName: "fixed_masses_church_id_fkey"
            columns: ["church_id"]
            isOneToOne: false
            referencedRelation: "churches"
            referencedColumns: ["id"]
          },
        ]
      }
      prayer_times: {
        Row: {
          church_id: string
          days: string
          id: string
          label: string
          time: string
        }
        Insert: {
          church_id: string
          days: string
          id?: string
          label: string
          time: string
        }
        Update: {
          church_id?: string
          days?: string
          id?: string
          label?: string
          time?: string
        }
        Relationships: [
          {
            foreignKeyName: "prayer_times_church_id_fkey"
            columns: ["church_id"]
            isOneToOne: false
            referencedRelation: "churches"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string | null
          email: string | null
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          email?: string | null
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          display_name?: string | null
          email?: string | null
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      supervisor_config: {
        Row: {
          global_password_hash: string | null
          id: string
          password_mode: string
          updated_at: string
        }
        Insert: {
          global_password_hash?: string | null
          id?: string
          password_mode?: string
          updated_at?: string
        }
        Update: {
          global_password_hash?: string | null
          id?: string
          password_mode?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          church_id: string | null
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          church_id?: string | null
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          church_id?: string | null
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_roles_church_id_fkey"
            columns: ["church_id"]
            isOneToOne: false
            referencedRelation: "churches"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_add_activity: {
        Args: {
          _activity_type: string
          _admin_code: string
          _church_id: string
          _day: string
          _location?: string
          _sort_time: string
          _time: string
        }
        Returns: string
      }
      admin_add_donation: {
        Args: {
          _admin_code: string
          _details: string
          _label: string
          _payment_method: string
          _section: string
          _sort_order?: number
        }
        Returns: string
      }
      admin_approve_activity: {
        Args: { _activity_id: string; _admin_code: string }
        Returns: boolean
      }
      admin_code_exists: { Args: never; Returns: boolean }
      admin_delete_activity: {
        Args: { _activity_id: string; _admin_code: string }
        Returns: boolean
      }
      admin_delete_donation: {
        Args: { _admin_code: string; _donation_id: string }
        Returns: boolean
      }
      admin_get_activities: {
        Args: { _admin_code: string; _church_id: string }
        Returns: {
          act_confirmations: number
          act_created_at: string
          act_day: string
          act_id: string
          act_location: string
          act_needed: number
          act_sort_time: string
          act_status: string
          act_time: string
          act_type: string
        }[]
      }
      admin_set_church_password: {
        Args: { _admin_code: string; _church_id: string; _password: string }
        Returns: boolean
      }
      admin_set_global_password: {
        Args: { _admin_code: string; _password: string }
        Returns: boolean
      }
      admin_set_password_mode: {
        Args: { _admin_code: string; _mode: string }
        Returns: boolean
      }
      bootstrap_admin_code: { Args: { _new_code: string }; Returns: boolean }
      change_admin_code: {
        Args: { _current_code: string; _new_code: string }
        Returns: boolean
      }
      confirm_activity: { Args: { _activity_id: string }; Returns: undefined }
      get_password_mode: { Args: never; Returns: string }
      get_supervisor_church_ids: {
        Args: { _user_id: string }
        Returns: string[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      set_church_password: {
        Args: { _church_id: string; _password: string }
        Returns: undefined
      }
      set_global_password: { Args: { _password: string }; Returns: undefined }
      set_password_mode: { Args: { _mode: string }; Returns: undefined }
      supervisor_add_activity: {
        Args: {
          _activity_type: string
          _church_id: string
          _day: string
          _location?: string
          _password: string
          _sort_time: string
          _time: string
        }
        Returns: string
      }
      supervisor_approve_activity: {
        Args: { _activity_id: string; _password: string }
        Returns: undefined
      }
      supervisor_delete_activity: {
        Args: { _activity_id: string; _password: string }
        Returns: undefined
      }
      supervisor_get_activities: {
        Args: { _church_id: string; _password: string }
        Returns: {
          act_confirmations: number
          act_created_at: string
          act_day: string
          act_id: string
          act_location: string
          act_needed: number
          act_sort_time: string
          act_status: string
          act_time: string
          act_type: string
        }[]
      }
      verify_admin_code: { Args: { _code: string }; Returns: boolean }
      verify_supervisor_password: {
        Args: { _church_id?: string; _password: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "supervisor"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "supervisor"],
    },
  },
} as const
