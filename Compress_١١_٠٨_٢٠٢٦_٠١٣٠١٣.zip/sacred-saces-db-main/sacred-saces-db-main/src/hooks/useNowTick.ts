import { useEffect, useState } from "react";

/**
 * Re-renders every `intervalMs` so time-dependent UI (e.g. "ended" badges)
 * stays in sync without manual refresh.
 */
export const useNowTick = (intervalMs = 30_000) => {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
};
