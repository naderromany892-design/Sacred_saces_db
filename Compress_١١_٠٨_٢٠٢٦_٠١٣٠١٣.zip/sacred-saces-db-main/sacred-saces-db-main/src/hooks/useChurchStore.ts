import { useEffect, useState, useCallback } from "react";
import { sampleChurches } from "@/data/churches";
import type { Church, ChurchActivity, DayName } from "@/types/church";

const CHURCHES_KEY = "admin_churches_v1";
const ACTIVITIES_KEY = "admin_activities_v1";
const DELETED_ACTIVITIES_KEY = "admin_deleted_activities_v1";
const DELETED_CHURCHES_KEY = "admin_deleted_churches_v1";
const CHURCH_OVERRIDES_KEY = "admin_church_overrides_v1";
const STORE_EVENT = "church-store-changed";

type ChurchOverride = Partial<Pick<Church, "name" | "city" | "address" | "imageUrl" | "governorate">> & {
  subRegion?: string;
};

type AdminActivity = ChurchActivity & { churchId: string };

const readJSON = <T>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
};

const writeJSON = (key: string, value: unknown) => {
  localStorage.setItem(key, JSON.stringify(value));
  window.dispatchEvent(new Event(STORE_EVENT));
};

export const useChurchStore = () => {
  const [version, setVersion] = useState(0);

  useEffect(() => {
    const refresh = () => setVersion((v) => v + 1);
    window.addEventListener(STORE_EVENT, refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener(STORE_EVENT, refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  const adminChurches = readJSON<Church[]>(CHURCHES_KEY, []);
  const adminActivities = readJSON<AdminActivity[]>(ACTIVITIES_KEY, []);
  const deletedActivities = readJSON<string[]>(DELETED_ACTIVITIES_KEY, []);

  const deletedChurches = readJSON<string[]>(DELETED_CHURCHES_KEY, []);
  const churchOverrides = readJSON<Record<string, ChurchOverride>>(CHURCH_OVERRIDES_KEY, {});

  // Merge sample + admin, apply overrides, filter deleted
  const allChurches: Church[] = [...sampleChurches, ...adminChurches]
    .filter((c) => !deletedChurches.includes(c.id))
    .map((c) => {
      const extra = adminActivities.filter((a) => a.churchId === c.id);
      const filtered = c.activities.filter((a) => !deletedActivities.includes(a.id));
      const override = churchOverrides[c.id] || {};
      return {
        ...c,
        ...override,
        activities: [...filtered, ...extra.map(({ churchId, ...rest }) => rest)],
      };
    });

  const addChurch = useCallback((church: Omit<Church, "id" | "activities" | "fixedMasses" | "prayerTimes">) => {
    const list = readJSON<Church[]>(CHURCHES_KEY, []);
    const newChurch: Church = {
      ...church,
      id: `admin-${crypto.randomUUID()}`,
      activities: [],
      fixedMasses: [],
      prayerTimes: [],
    };
    writeJSON(CHURCHES_KEY, [...list, newChurch]);
    return newChurch;
  }, []);

  const addActivity = useCallback((churchId: string, activity: Omit<ChurchActivity, "id">) => {
    const list = readJSON<AdminActivity[]>(ACTIVITIES_KEY, []);
    const newAct: AdminActivity = { ...activity, id: `act-${crypto.randomUUID()}`, churchId };
    writeJSON(ACTIVITIES_KEY, [...list, newAct]);
  }, []);

  const updateActivity = useCallback((churchId: string, activityId: string, patch: Partial<Omit<ChurchActivity, "id">>) => {
    // Update admin-added activity if exists
    const list = readJSON<AdminActivity[]>(ACTIVITIES_KEY, []);
    const idx = list.findIndex((a) => a.id === activityId);
    if (idx !== -1) {
      const next = [...list];
      next[idx] = { ...next[idx], ...patch };
      writeJSON(ACTIVITIES_KEY, next);
      return;
    }
    // Otherwise it's a sample activity: mark deleted + re-add edited as admin
    const sample = sampleChurches
      .find((c) => c.id === churchId)?.activities.find((a) => a.id === activityId);
    if (!sample) return;
    const deleted = readJSON<string[]>(DELETED_ACTIVITIES_KEY, []);
    if (!deleted.includes(activityId)) writeJSON(DELETED_ACTIVITIES_KEY, [...deleted, activityId]);
    const merged: AdminActivity = { ...sample, ...patch, id: `act-${crypto.randomUUID()}`, churchId };
    const list2 = readJSON<AdminActivity[]>(ACTIVITIES_KEY, []);
    writeJSON(ACTIVITIES_KEY, [...list2, merged]);
  }, []);

  const removeActivity = useCallback((churchId: string, activityId: string) => {
    const list = readJSON<AdminActivity[]>(ACTIVITIES_KEY, []);
    const next = list.filter((a) => a.id !== activityId);
    if (next.length !== list.length) {
      writeJSON(ACTIVITIES_KEY, next);
    } else {
      // Was a sample activity - mark as deleted
      const deleted = readJSON<string[]>(DELETED_ACTIVITIES_KEY, []);
      writeJSON(DELETED_ACTIVITIES_KEY, [...deleted, activityId]);
    }
  }, []);


  const updateChurch = useCallback((churchId: string, patch: ChurchOverride) => {
    // If admin-added church, edit directly
    const list = readJSON<Church[]>(CHURCHES_KEY, []);
    const idx = list.findIndex((c) => c.id === churchId);
    if (idx !== -1) {
      const next = [...list];
      next[idx] = { ...next[idx], ...patch };
      writeJSON(CHURCHES_KEY, next);
      return;
    }
    // Otherwise store as override for sample church
    const overrides = readJSON<Record<string, ChurchOverride>>(CHURCH_OVERRIDES_KEY, {});
    overrides[churchId] = { ...(overrides[churchId] || {}), ...patch };
    writeJSON(CHURCH_OVERRIDES_KEY, overrides);
  }, []);

  const deleteChurch = useCallback((churchId: string) => {
    const list = readJSON<Church[]>(CHURCHES_KEY, []);
    const next = list.filter((c) => c.id !== churchId);
    if (next.length !== list.length) {
      writeJSON(CHURCHES_KEY, next);
      return;
    }
    const deleted = readJSON<string[]>(DELETED_CHURCHES_KEY, []);
    if (!deleted.includes(churchId)) writeJSON(DELETED_CHURCHES_KEY, [...deleted, churchId]);
  }, []);

  return { churches: allChurches, addChurch, updateChurch, deleteChurch, addActivity, updateActivity, removeActivity, version };
};
