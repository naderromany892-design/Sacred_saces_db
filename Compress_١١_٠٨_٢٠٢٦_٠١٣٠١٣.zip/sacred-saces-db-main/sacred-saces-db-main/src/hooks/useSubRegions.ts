import { useEffect, useState, useCallback } from "react";

const KEY = "admin_subregions_v1";
const EVENT = "subregions-changed";

export interface SubRegion {
  id: string;
  governorate: string;
  name: string;
}

const read = (): SubRegion[] => {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as SubRegion[]) : [];
  } catch {
    return [];
  }
};

const write = (list: SubRegion[]) => {
  localStorage.setItem(KEY, JSON.stringify(list));
  window.dispatchEvent(new Event(EVENT));
};

export const useSubRegions = (governorate?: string) => {
  const [version, setVersion] = useState(0);

  useEffect(() => {
    const refresh = () => setVersion((v) => v + 1);
    window.addEventListener(EVENT, refresh);
    window.addEventListener("storage", refresh);
    return () => {
      window.removeEventListener(EVENT, refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  const all = read();
  const list = governorate ? all.filter((s) => s.governorate === governorate) : all;

  const addSubRegion = useCallback((gov: string, name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    const cur = read();
    if (cur.some((s) => s.governorate === gov && s.name === trimmed)) return;
    write([...cur, { id: `sr-${crypto.randomUUID()}`, governorate: gov, name: trimmed }]);
  }, []);

  const renameSubRegion = useCallback((id: string, name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    const cur = read();
    write(cur.map((s) => (s.id === id ? { ...s, name: trimmed } : s)));
  }, []);

  const removeSubRegion = useCallback((id: string) => {
    write(read().filter((s) => s.id !== id));
  }, []);

  return { subRegions: list, addSubRegion, renameSubRegion, removeSubRegion, version };
};
