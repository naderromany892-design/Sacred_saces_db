import { useState, useCallback, useEffect } from "react";

const STORAGE_KEY = "church-favorites";

export function useFavorites() {
  const [favorites, setFavorites] = useState<Set<string>>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? new Set(JSON.parse(stored)) : new Set();
    } catch {
      return new Set();
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([...favorites]));
  }, [favorites]);

  const toggleFavorite = useCallback((churchId: string) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      if (next.has(churchId)) next.delete(churchId);
      else next.add(churchId);
      return next;
    });
  }, []);

  const isFavorite = useCallback((churchId: string) => favorites.has(churchId), [favorites]);

  return { favorites, toggleFavorite, isFavorite };
}
