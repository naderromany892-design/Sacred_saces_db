// Simplified auth - code-based admin system, no email/password
// Admin code is verified via RPC, stored in sessionStorage

export function getAdminCode(): string | null {
  return sessionStorage.getItem("admin_code");
}

export function getSupervisorPassword(): string | null {
  return sessionStorage.getItem("supervisor_password");
}

export function isAdminSession(): boolean {
  return sessionStorage.getItem("is_admin") === "true";
}

export function setAdminSession(code: string) {
  sessionStorage.setItem("admin_code", code);
  sessionStorage.setItem("is_admin", "true");
}

export function setSupervisorSession(password: string, churchId?: string) {
  sessionStorage.setItem("supervisor_password", password);
  if (churchId) sessionStorage.setItem("supervisor_church_id", churchId);
}

export function clearSession() {
  sessionStorage.removeItem("admin_code");
  sessionStorage.removeItem("is_admin");
  sessionStorage.removeItem("supervisor_password");
  sessionStorage.removeItem("supervisor_church_id");
  sessionStorage.removeItem("supervisor_mode");
}

export function getAccessCode(): string | null {
  return getAdminCode() || getSupervisorPassword();
}
