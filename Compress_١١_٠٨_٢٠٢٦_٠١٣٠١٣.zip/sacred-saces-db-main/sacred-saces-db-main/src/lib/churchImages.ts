// Default imagery utilities — local only.
// Picks a default church image if none provided, and detects saint name in church titles
// to show a small saint avatar (emoji-based, swappable).

const DEFAULT_CHURCH_IMAGES = [
  "https://images.unsplash.com/photo-1548625149-fc4a29cf7092?w=800&h=400&fit=crop",
  "https://images.unsplash.com/photo-1438032005730-c779502df39b?w=800&h=400&fit=crop",
  "https://images.unsplash.com/photo-1519677100203-a0e668c92439?w=800&h=400&fit=crop",
  "https://images.unsplash.com/photo-1507692049790-de58290a4334?w=800&h=400&fit=crop",
  "https://images.unsplash.com/photo-1473177104440-ffee2f376098?w=800&h=400&fit=crop",
];

export function getDefaultChurchImage(seed?: string): string {
  if (!seed) return DEFAULT_CHURCH_IMAGES[0];
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash = (hash * 31 + seed.charCodeAt(i)) >>> 0;
  return DEFAULT_CHURCH_IMAGES[hash % DEFAULT_CHURCH_IMAGES.length];
}

export interface SaintInfo {
  name: string;
  emoji: string;
}

// Detect a saint in a church name (Arabic). Order matters — longer/more specific first.
const SAINT_PATTERNS: { keys: string[]; saint: SaintInfo }[] = [
  { keys: ["العذراء", "مريم", "السيدة العذراء"], saint: { name: "السيدة العذراء", emoji: "👰🏻" } },
  { keys: ["مارجرجس", "جرجس", "مار جرجس"], saint: { name: "مارجرجس", emoji: "🐉" } },
  { keys: ["الملاك ميخائيل", "ميخائيل", "الملاك"], saint: { name: "الملاك ميخائيل", emoji: "👼" } },
  { keys: ["الأنبا أنطونيوس", "أنطونيوس", "انطونيوس"], saint: { name: "الأنبا أنطونيوس", emoji: "🧔🏽" } },
  { keys: ["الأنبا بيشوي", "بيشوي"], saint: { name: "الأنبا بيشوي", emoji: "🙏🏽" } },
  { keys: ["الأنبا مكاريوس", "مكاريوس"], saint: { name: "الأنبا مكاريوس", emoji: "🕊️" } },
  { keys: ["مار مرقس", "مرقس", "المرقسية"], saint: { name: "مار مرقس", emoji: "🦁" } },
  { keys: ["مار بطرس", "بطرس"], saint: { name: "مار بطرس", emoji: "🗝️" } },
  { keys: ["مار بولس", "بولس"], saint: { name: "مار بولس", emoji: "📜" } },
  { keys: ["مارمينا", "مينا"], saint: { name: "مارمينا", emoji: "🐪" } },
  { keys: ["أبو سيفين", "ابو سيفين", "فيلوباتير"], saint: { name: "أبو سيفين", emoji: "⚔️" } },
  { keys: ["كيرلس"], saint: { name: "البابا كيرلس", emoji: "✝️" } },
  { keys: ["تكلا"], saint: { name: "القديسة تكلاهيمانوت", emoji: "🌿" } },
  { keys: ["دميانة"], saint: { name: "الشهيدة دميانة", emoji: "🌸" } },
  { keys: ["المسيح", "يسوع", "السيد المسيح"], saint: { name: "السيد المسيح", emoji: "✝️" } },
];

export function detectSaint(churchName: string): SaintInfo | null {
  if (!churchName) return null;
  const normalized = churchName.replace(/[إأآ]/g, "ا");
  for (const { keys, saint } of SAINT_PATTERNS) {
    for (const k of keys) {
      const nk = k.replace(/[إأآ]/g, "ا");
      if (normalized.includes(nk)) return saint;
    }
  }
  return null;
}

// Allow admins to override saint avatar (image url) per church
const SAINT_OVERRIDES_KEY = "admin_saint_overrides_v1";

export function getSaintOverride(churchId: string): string | null {
  try {
    const raw = localStorage.getItem(SAINT_OVERRIDES_KEY);
    if (!raw) return null;
    const map = JSON.parse(raw) as Record<string, string>;
    return map[churchId] || null;
  } catch {
    return null;
  }
}

export function setSaintOverride(churchId: string, imageUrl: string) {
  try {
    const raw = localStorage.getItem(SAINT_OVERRIDES_KEY);
    const map = raw ? (JSON.parse(raw) as Record<string, string>) : {};
    if (imageUrl) map[churchId] = imageUrl;
    else delete map[churchId];
    localStorage.setItem(SAINT_OVERRIDES_KEY, JSON.stringify(map));
    window.dispatchEvent(new Event("church-store-changed"));
  } catch {
    // ignore
  }
}
