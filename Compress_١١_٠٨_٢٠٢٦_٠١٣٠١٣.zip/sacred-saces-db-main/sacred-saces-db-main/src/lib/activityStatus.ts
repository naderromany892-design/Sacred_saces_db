import type { ChurchActivity, DayName } from "@/types/church";

const DAY_TO_INDEX: Record<DayName, number> = {
  "الأحد": 0, "الاثنين": 1, "الثلاثاء": 2, "الأربعاء": 3,
  "الخميس": 4, "الجمعة": 5, "السبت": 6,
};

/**
 * Returns true if the activity has an end time AND we are currently
 * past that end time on the activity's scheduled day.
 *
 * Uses sortTime (24h "HH:MM") for comparison.
 */
export const isActivityEnded = (a: ChurchActivity, now: Date = new Date()): boolean => {
  if (!a.endSortTime) return false;
  if (now.getDay() !== DAY_TO_INDEX[a.day]) return false;
  const [eh, em] = a.endSortTime.split(":").map((x) => parseInt(x, 10));
  if (Number.isNaN(eh) || Number.isNaN(em)) return false;
  const minutesNow = now.getHours() * 60 + now.getMinutes();
  const minutesEnd = eh * 60 + em;
  return minutesNow >= minutesEnd;
};
