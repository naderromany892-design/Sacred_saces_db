export type DayName = "السبت" | "الأحد" | "الاثنين" | "الثلاثاء" | "الأربعاء" | "الخميس" | "الجمعة";

export const DAYS: DayName[] = ["السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"];

export type ActivityType = "قداس" | "اجتماع" | "تسبحة" | "خدمة" | "اجتماع شباب" | "مدارس الأحد";

export const ACTIVITY_TYPES: ActivityType[] = ["قداس", "اجتماع", "تسبحة", "خدمة", "اجتماع شباب", "مدارس الأحد"];

export interface ChurchActivity {
  id: string;
  day: DayName;
  type: ActivityType;
  time: string;
  sortTime: string;
  location: string;
  endTime?: string;
  endSortTime?: string;
}

export interface FixedSchedule {
  label: string;
  time: string;
  days: string;
}

export interface Church {
  id: string;
  name: string;
  governorate: string;
  city: string;
  address: string;
  imageUrl: string;
  subRegion?: string;
  fixedMasses: FixedSchedule[];
  prayerTimes: FixedSchedule[];
  activities: ChurchActivity[];
}

export const GOVERNORATES = [
  "القاهرة", "الجيزة", "الإسكندرية", "القليوبية", "الدقهلية", "الشرقية",
  "الغربية", "المنوفية", "البحيرة", "كفر الشيخ", "دمياط", "بورسعيد",
  "الإسماعيلية", "السويس", "شمال سيناء", "جنوب سيناء", "بني سويف", "الفيوم",
  "المنيا", "أسيوط", "سوهاج", "قنا", "الأقصر", "أسوان",
  "البحر الأحمر", "الوادي الجديد", "مطروح",
];
