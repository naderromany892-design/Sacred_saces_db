import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index";
import ChurchList from "./pages/ChurchList";
import ChurchDetail from "./pages/ChurchDetail";
import AdminDashboard from "./pages/AdminDashboard";
import NotFound from "./pages/NotFound";
import Donations from "./pages/Donations";
import Favorites from "./pages/Favorites";
import SubRegions from "./pages/SubRegions";
import VoiceAssistant from "./components/VoiceAssistant";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/governorate/:governorate" element={<ChurchList />} />
          <Route path="/governorate/:governorate/subregions" element={<SubRegions />} />
          <Route path="/governorate/:governorate/sub/:subRegion" element={<ChurchList />} />
          <Route path="/church/:id" element={<ChurchDetail />} />
          <Route path="/favorites" element={<Favorites />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/donations" element={<Donations />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <VoiceAssistant />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
