import type { Church } from "@/types/church";

export const sampleChurches: Church[] = [
  {
    id: "1",
    name: "كنيسة العذراء مريم - الزيتون",
    governorate: "القاهرة",
    city: "الزيتون",
    address: "شارع طومان باي، الزيتون، القاهرة",
    imageUrl: "https://images.unsplash.com/photo-1548625149-fc4a29cf7092?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ١٠:٠٠ ص", days: "الأحد والأربعاء والجمعة" },
      { label: "قداس باكر", time: "٦:٠٠ - ٧:٠٠ ص", days: "يومياً" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٥:٠٠ م", days: "يومياً" },
      { label: "صلاة نصف الليل", time: "١٢:٠٠ ص", days: "السبت" },
    ],
    activities: [
      { id: "a1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الكبرى" },
      { id: "a2", day: "الأحد", type: "مدارس الأحد", time: "١٠:٠٠ ص", sortTime: "10:00", location: "قاعة التعليم" },
      { id: "a3", day: "الأحد", type: "اجتماع شباب", time: "٦:٠٠ م", sortTime: "18:00", location: "قاعة الأنشطة" },
      { id: "a4", day: "الأربعاء", type: "قداس", time: "٦:٠٠ م", sortTime: "18:00", location: "الكنيسة الكبرى" },
      { id: "a5", day: "الجمعة", type: "تسبحة", time: "٩:٠٠ ص", sortTime: "09:00", location: "صحن الكنيسة" },
      { id: "a6", day: "السبت", type: "اجتماع", time: "٥:٠٠ م", sortTime: "17:00", location: "قاعة المؤتمرات" },
      { id: "a7", day: "الثلاثاء", type: "خدمة", time: "١٠:٠٠ ص", sortTime: "10:00", location: "مبنى الخدمات" },
    ],
  },
  {
    id: "2",
    name: "الكاتدرائية المرقسية - العباسية",
    governorate: "القاهرة",
    city: "العباسية",
    address: "شارع رمسيس، العباسية، القاهرة",
    imageUrl: "https://images.unsplash.com/photo-1438032005730-c779502df39b?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٨:٠٠ - ١١:٠٠ ص", days: "الأحد والجمعة" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٦:٠٠ م", days: "يومياً" },
    ],
    activities: [
      { id: "b1", day: "الأحد", type: "قداس", time: "٨:٠٠ ص", sortTime: "08:00", location: "الكاتدرائية الكبرى" },
      { id: "b2", day: "الأحد", type: "مدارس الأحد", time: "١١:٠٠ ص", sortTime: "11:00", location: "مبنى التعليم" },
      { id: "b3", day: "الجمعة", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكاتدرائية" },
      { id: "b4", day: "الخميس", type: "تسبحة", time: "٨:٠٠ م", sortTime: "20:00", location: "صحن الكنيسة" },
      { id: "b5", day: "الاثنين", type: "اجتماع شباب", time: "٧:٠٠ م", sortTime: "19:00", location: "قاعة الشباب" },
      { id: "b6", day: "السبت", type: "اجتماع", time: "٤:٠٠ م", sortTime: "16:00", location: "القاعة الكبرى" },
    ],
  },
  {
    id: "3",
    name: "كنيسة الأنبا أنطونيوس - مدينة نصر",
    governorate: "القاهرة",
    city: "مدينة نصر",
    address: "شارع الطيران، مدينة نصر، القاهرة",
    imageUrl: "",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٦:٠٠ - ٩:٠٠ ص", days: "السبت والأحد" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٥:٣٠ م", days: "يومياً" },
    ],
    activities: [
      { id: "c1", day: "السبت", type: "قداس", time: "٦:٠٠ ص", sortTime: "06:00", location: "الكنيسة الصغرى" },
      { id: "c2", day: "الأحد", type: "قداس", time: "٨:٣٠ ص", sortTime: "08:30", location: "الكنيسة الكبرى" },
      { id: "c3", day: "الأحد", type: "مدارس الأحد", time: "١٢:٠٠ م", sortTime: "12:00", location: "مبنى الخدمات" },
      { id: "c4", day: "الخميس", type: "اجتماع", time: "٦:٠٠ م", sortTime: "18:00", location: "القاعة الرئيسية" },
    ],
  },
  {
    id: "4",
    name: "كنيسة مارجرجس - سبورتنج",
    governorate: "الإسكندرية",
    city: "سبورتنج",
    address: "شارع النبي دانيال، سبورتنج، الإسكندرية",
    imageUrl: "https://images.unsplash.com/photo-1548625149-fc4a29cf7092?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٣٠ - ١٠:٠٠ ص", days: "الأحد والجمعة" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٥:٠٠ م", days: "يومياً" },
    ],
    activities: [
      { id: "d1", day: "الأحد", type: "قداس", time: "٧:٣٠ ص", sortTime: "07:30", location: "الهيكل الرئيسي" },
      { id: "d2", day: "الأحد", type: "مدارس الأحد", time: "١٠:٣٠ ص", sortTime: "10:30", location: "قاعة التعليم" },
      { id: "d3", day: "الجمعة", type: "قداس", time: "٥:٠٠ م", sortTime: "17:00", location: "الهيكل الرئيسي" },
      { id: "d4", day: "الخميس", type: "تسبحة", time: "٨:٠٠ م", sortTime: "20:00", location: "صحن الكنيسة" },
      { id: "d5", day: "الثلاثاء", type: "اجتماع شباب", time: "٧:٠٠ م", sortTime: "19:00", location: "قاعة الشباب" },
    ],
  },
  {
    id: "5",
    name: "كنيسة العذراء - كليوباترا",
    governorate: "الإسكندرية",
    city: "كليوباترا",
    address: "شارع مصطفى كامل، كليوباترا، الإسكندرية",
    imageUrl: "",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٨:٠٠ - ١٠:٣٠ ص", days: "الأحد والأربعاء" },
    ],
    prayerTimes: [],
    activities: [
      { id: "e1", day: "الأحد", type: "قداس", time: "٨:٠٠ ص", sortTime: "08:00", location: "الكنيسة الرئيسية" },
      { id: "e2", day: "الأربعاء", type: "قداس", time: "٦:٠٠ م", sortTime: "18:00", location: "الكنيسة الرئيسية" },
      { id: "e3", day: "السبت", type: "تسبحة", time: "٧:٠٠ م", sortTime: "19:00", location: "صحن الكنيسة" },
    ],
  },
  {
    id: "6",
    name: "كنيسة مارمينا - فيصل",
    governorate: "الجيزة",
    city: "فيصل",
    address: "شارع فيصل الرئيسي، الجيزة",
    imageUrl: "https://images.unsplash.com/photo-1438032005730-c779502df39b?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ١٠:٠٠ ص", days: "الأحد والجمعة" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٥:٠٠ م", days: "يومياً" },
    ],
    activities: [
      { id: "f1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "f2", day: "الأحد", type: "مدارس الأحد", time: "١٠:٠٠ ص", sortTime: "10:00", location: "مبنى الخدمات" },
      { id: "f3", day: "الجمعة", type: "تسبحة", time: "٦:٠٠ م", sortTime: "18:00", location: "صحن الكنيسة" },
      { id: "f4", day: "الاثنين", type: "خدمة", time: "٩:٠٠ ص", sortTime: "09:00", location: "مبنى الخدمات" },
    ],
  },
  {
    id: "7",
    name: "كنيسة الأنبا بيشوي",
    governorate: "المنيا",
    city: "المنيا",
    address: "شارع كورنيش النيل، المنيا",
    imageUrl: "",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ٩:٣٠ ص", days: "الأحد والأربعاء" },
    ],
    prayerTimes: [],
    activities: [
      { id: "g1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "g2", day: "الأربعاء", type: "قداس", time: "٥:٠٠ م", sortTime: "17:00", location: "الكنيسة الرئيسية" },
      { id: "g3", day: "الجمعة", type: "اجتماع شباب", time: "٧:٠٠ م", sortTime: "19:00", location: "قاعة الأنشطة" },
      { id: "g4", day: "السبت", type: "مدارس الأحد", time: "١٠:٠٠ ص", sortTime: "10:00", location: "قاعة التعليم" },
    ],
  },
  {
    id: "8",
    name: "كنيسة العذراء مريم",
    governorate: "أسيوط",
    city: "أسيوط",
    address: "شارع الجمهورية، أسيوط",
    imageUrl: "https://images.unsplash.com/photo-1548625149-fc4a29cf7092?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٣٠ - ١٠:٠٠ ص", days: "الأحد" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٦:٠٠ م", days: "يومياً" },
    ],
    activities: [
      { id: "h1", day: "الأحد", type: "قداس", time: "٧:٣٠ ص", sortTime: "07:30", location: "الكنيسة الكبرى" },
      { id: "h2", day: "الأحد", type: "مدارس الأحد", time: "١١:٠٠ ص", sortTime: "11:00", location: "قاعة التعليم" },
      { id: "h3", day: "الخميس", type: "تسبحة", time: "٧:٠٠ م", sortTime: "19:00", location: "صحن الكنيسة" },
      { id: "h4", day: "السبت", type: "اجتماع", time: "٥:٠٠ م", sortTime: "17:00", location: "القاعة الرئيسية" },
    ],
  },
  {
    id: "9",
    name: "كنيسة مارجرجس - شبرا",
    governorate: "القليوبية",
    city: "شبرا الخيمة",
    address: "شارع أحمد عرابي، شبرا الخيمة",
    imageUrl: "",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ٩:٣٠ ص", days: "الأحد والجمعة" },
    ],
    prayerTimes: [],
    activities: [
      { id: "i1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "i2", day: "الأحد", type: "مدارس الأحد", time: "١٠:٣٠ ص", sortTime: "10:30", location: "قاعة التعليم" },
      { id: "i3", day: "الجمعة", type: "قداس", time: "٦:٠٠ ص", sortTime: "06:00", location: "الكنيسة الرئيسية" },
      { id: "i4", day: "الخميس", type: "اجتماع شباب", time: "٧:٠٠ م", sortTime: "19:00", location: "قاعة الشباب" },
    ],
  },
  {
    id: "10",
    name: "كنيسة العذراء - المنصورة",
    governorate: "الدقهلية",
    city: "المنصورة",
    address: "شارع الجيش، المنصورة",
    imageUrl: "https://images.unsplash.com/photo-1438032005730-c779502df39b?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٣٠ - ١٠:٠٠ ص", days: "الأحد" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٥:٣٠ م", days: "يومياً" },
    ],
    activities: [
      { id: "j1", day: "الأحد", type: "قداس", time: "٧:٣٠ ص", sortTime: "07:30", location: "الكنيسة الكبرى" },
      { id: "j2", day: "الأحد", type: "مدارس الأحد", time: "١٠:٠٠ ص", sortTime: "10:00", location: "مبنى التعليم" },
      { id: "j3", day: "الأربعاء", type: "اجتماع", time: "٦:٠٠ م", sortTime: "18:00", location: "القاعة الرئيسية" },
    ],
  },
  {
    id: "11",
    name: "كنيسة مارمرقس - الزقازيق",
    governorate: "الشرقية",
    city: "الزقازيق",
    address: "شارع فاروق، الزقازيق",
    imageUrl: "",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ٩:٣٠ ص", days: "الأحد والجمعة" },
    ],
    prayerTimes: [],
    activities: [
      { id: "k1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "k2", day: "الجمعة", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "k3", day: "السبت", type: "تسبحة", time: "٧:٠٠ م", sortTime: "19:00", location: "صحن الكنيسة" },
    ],
  },
  {
    id: "12",
    name: "كنيسة الأنبا شنودة - طنطا",
    governorate: "الغربية",
    city: "طنطا",
    address: "شارع البحر، طنطا",
    imageUrl: "https://images.unsplash.com/photo-1548625149-fc4a29cf7092?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٣٠ - ١٠:٠٠ ص", days: "الأحد" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٥:٠٠ م", days: "يومياً" },
    ],
    activities: [
      { id: "l1", day: "الأحد", type: "قداس", time: "٧:٣٠ ص", sortTime: "07:30", location: "الكنيسة الكبرى" },
      { id: "l2", day: "الأحد", type: "مدارس الأحد", time: "١٠:٣٠ ص", sortTime: "10:30", location: "قاعة التعليم" },
      { id: "l3", day: "الخميس", type: "اجتماع شباب", time: "٧:٠٠ م", sortTime: "19:00", location: "قاعة الشباب" },
    ],
  },
  {
    id: "13",
    name: "كنيسة العذراء - شبين الكوم",
    governorate: "المنوفية",
    city: "شبين الكوم",
    address: "شارع الجلاء، شبين الكوم",
    imageUrl: "",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ٩:٠٠ ص", days: "الأحد" },
    ],
    prayerTimes: [],
    activities: [
      { id: "m1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "m2", day: "السبت", type: "اجتماع", time: "٥:٠٠ م", sortTime: "17:00", location: "القاعة الرئيسية" },
    ],
  },
  {
    id: "14",
    name: "كنيسة مارجرجس - دمنهور",
    governorate: "البحيرة",
    city: "دمنهور",
    address: "شارع سعد زغلول، دمنهور",
    imageUrl: "https://images.unsplash.com/photo-1438032005730-c779502df39b?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٣٠ - ١٠:٠٠ ص", days: "الأحد والجمعة" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٥:٠٠ م", days: "يومياً" },
    ],
    activities: [
      { id: "n1", day: "الأحد", type: "قداس", time: "٧:٣٠ ص", sortTime: "07:30", location: "الكنيسة الرئيسية" },
      { id: "n2", day: "الجمعة", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "n3", day: "الأربعاء", type: "تسبحة", time: "٧:٠٠ م", sortTime: "19:00", location: "صحن الكنيسة" },
    ],
  },
  {
    id: "15",
    name: "كنيسة العذراء - بورسعيد",
    governorate: "بورسعيد",
    city: "بورسعيد",
    address: "شارع محمد علي، بورسعيد",
    imageUrl: "",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ٩:٣٠ ص", days: "الأحد" },
    ],
    prayerTimes: [],
    activities: [
      { id: "o1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "o2", day: "الجمعة", type: "خدمة", time: "١٠:٠٠ ص", sortTime: "10:00", location: "مبنى الخدمات" },
    ],
  },
  {
    id: "16",
    name: "كنيسة الأنبا بولا - الإسماعيلية",
    governorate: "الإسماعيلية",
    city: "الإسماعيلية",
    address: "شارع الثلاثيني، الإسماعيلية",
    imageUrl: "https://images.unsplash.com/photo-1548625149-fc4a29cf7092?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٣٠ - ١٠:٠٠ ص", days: "الأحد والأربعاء" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٥:٣٠ م", days: "يومياً" },
    ],
    activities: [
      { id: "p1", day: "الأحد", type: "قداس", time: "٧:٣٠ ص", sortTime: "07:30", location: "الكنيسة الرئيسية" },
      { id: "p2", day: "الأربعاء", type: "قداس", time: "٦:٠٠ م", sortTime: "18:00", location: "الكنيسة الرئيسية" },
      { id: "p3", day: "الجمعة", type: "اجتماع شباب", time: "٧:٠٠ م", sortTime: "19:00", location: "قاعة الشباب" },
    ],
  },
  {
    id: "17",
    name: "كنيسة مارجرجس - السويس",
    governorate: "السويس",
    city: "السويس",
    address: "شارع الجيش، السويس",
    imageUrl: "",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ٩:٣٠ ص", days: "الأحد" },
    ],
    prayerTimes: [],
    activities: [
      { id: "q1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "q2", day: "السبت", type: "تسبحة", time: "٧:٠٠ م", sortTime: "19:00", location: "صحن الكنيسة" },
    ],
  },
  {
    id: "18",
    name: "كنيسة العذراء - بني سويف",
    governorate: "بني سويف",
    city: "بني سويف",
    address: "شارع صلاح سالم، بني سويف",
    imageUrl: "https://images.unsplash.com/photo-1438032005730-c779502df39b?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ٩:٣٠ ص", days: "الأحد والجمعة" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٥:٠٠ م", days: "يومياً" },
    ],
    activities: [
      { id: "r1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "r2", day: "الأحد", type: "مدارس الأحد", time: "١٠:٠٠ ص", sortTime: "10:00", location: "قاعة التعليم" },
      { id: "r3", day: "الجمعة", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
    ],
  },
  {
    id: "19",
    name: "كنيسة مارمينا - الفيوم",
    governorate: "الفيوم",
    city: "الفيوم",
    address: "شارع الحرية، الفيوم",
    imageUrl: "",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ٩:٠٠ ص", days: "الأحد" },
    ],
    prayerTimes: [],
    activities: [
      { id: "s1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "s2", day: "السبت", type: "اجتماع", time: "٥:٠٠ م", sortTime: "17:00", location: "القاعة الرئيسية" },
    ],
  },
  {
    id: "20",
    name: "كنيسة مارجرجس - سوهاج",
    governorate: "سوهاج",
    city: "سوهاج",
    address: "شارع الكورنيش، سوهاج",
    imageUrl: "https://images.unsplash.com/photo-1548625149-fc4a29cf7092?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ٩:٣٠ ص", days: "الأحد والجمعة" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٥:٠٠ م", days: "يومياً" },
    ],
    activities: [
      { id: "t1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "t2", day: "الجمعة", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "t3", day: "الخميس", type: "تسبحة", time: "٧:٠٠ م", sortTime: "19:00", location: "صحن الكنيسة" },
    ],
  },
  {
    id: "21",
    name: "كنيسة العذراء - قنا",
    governorate: "قنا",
    city: "قنا",
    address: "شارع الجمهورية، قنا",
    imageUrl: "",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ٩:٠٠ ص", days: "الأحد" },
    ],
    prayerTimes: [],
    activities: [
      { id: "u1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
    ],
  },
  {
    id: "22",
    name: "كنيسة مارمرقس - الأقصر",
    governorate: "الأقصر",
    city: "الأقصر",
    address: "شارع المعبد، الأقصر",
    imageUrl: "https://images.unsplash.com/photo-1438032005730-c779502df39b?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٣٠ - ١٠:٠٠ ص", days: "الأحد والجمعة" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٥:٠٠ م", days: "يومياً" },
    ],
    activities: [
      { id: "v1", day: "الأحد", type: "قداس", time: "٧:٣٠ ص", sortTime: "07:30", location: "الكنيسة الرئيسية" },
      { id: "v2", day: "الجمعة", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "v3", day: "الأربعاء", type: "اجتماع", time: "٦:٠٠ م", sortTime: "18:00", location: "القاعة الرئيسية" },
    ],
  },
  {
    id: "23",
    name: "كنيسة الأنبا بيشوي - أسوان",
    governorate: "أسوان",
    city: "أسوان",
    address: "شارع كورنيش النيل، أسوان",
    imageUrl: "",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ٩:٣٠ ص", days: "الأحد" },
    ],
    prayerTimes: [],
    activities: [
      { id: "w1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "w2", day: "السبت", type: "تسبحة", time: "٧:٠٠ م", sortTime: "19:00", location: "صحن الكنيسة" },
    ],
  },
  {
    id: "24",
    name: "كنيسة العذراء - دمياط",
    governorate: "دمياط",
    city: "دمياط",
    address: "شارع الكورنيش، دمياط",
    imageUrl: "https://images.unsplash.com/photo-1548625149-fc4a29cf7092?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ٩:٣٠ ص", days: "الأحد والجمعة" },
    ],
    prayerTimes: [
      { label: "صلاة عشية", time: "٥:٣٠ م", days: "يومياً" },
    ],
    activities: [
      { id: "x1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "x2", day: "الجمعة", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
    ],
  },
  {
    id: "25",
    name: "كنيسة مارجرجس - كفر الشيخ",
    governorate: "كفر الشيخ",
    city: "كفر الشيخ",
    address: "شارع الجمهورية، كفر الشيخ",
    imageUrl: "",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٧:٠٠ - ٩:٠٠ ص", days: "الأحد" },
    ],
    prayerTimes: [],
    activities: [
      { id: "y1", day: "الأحد", type: "قداس", time: "٧:٠٠ ص", sortTime: "07:00", location: "الكنيسة الرئيسية" },
      { id: "y2", day: "السبت", type: "اجتماع شباب", time: "٦:٠٠ م", sortTime: "18:00", location: "قاعة الشباب" },
    ],
  },
  {
    id: "26",
    name: "كنيسة العذراء - الغردقة",
    governorate: "البحر الأحمر",
    city: "الغردقة",
    address: "شارع الشيراتون، الغردقة",
    imageUrl: "https://images.unsplash.com/photo-1438032005730-c779502df39b?w=800&h=400&fit=crop",
    fixedMasses: [
      { label: "القداس الإلهي", time: "٨:٠٠ - ١٠:٠٠ ص", days: "الأحد" },
    ],
    prayerTimes: [],
    activities: [
      { id: "z1", day: "الأحد", type: "قداس", time: "٨:٠٠ ص", sortTime: "08:00", location: "الكنيسة الرئيسية" },
    ],
  },
];
