import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowRight, Church, Heart, Sparkles, Copy, Check,
  Smartphone, Building2, CreditCard,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";

interface DonationSetting {
  id: string; section: string; payment_method: string; label: string; details: string; sort_order: number;
}

const sectionMeta: Record<string, { title: string; description: string; icon: React.ReactNode; color: string }> = {
  churches: {
    title: "دعم الكنائس",
    description: "تبرعك يذهب بالكامل للكنيسة المختارة لدعم خدماتها وأنشطتها.",
    icon: <Church className="w-6 h-6" />,
    color: "bg-primary/10 text-primary",
  },
  humanitarian: {
    title: "المساعدات الإنسانية",
    description: "ساهم في مساعدة الأسر المحتاجة ودعم الخدمات الاجتماعية.",
    icon: <Heart className="w-6 h-6" />,
    color: "bg-destructive/10 text-destructive",
  },
  app: {
    title: "دعم التطبيق",
    description: "يمكنك المساهمة في تطوير التطبيق ليصل لأكبر عدد من الناس، ويتم استخدام الدعم في تحسين الخدمة وتوفير الإمكانيات اللازمة.",
    icon: <Sparkles className="w-6 h-6" />,
    color: "bg-accent/20 text-accent-foreground",
  },
};

const usageItems = [
  "تحسين التطبيق وإضافة ميزات جديدة",
  "توفير أجهزة وبنية تحتية",
  "مصاريف التشغيل والاستضافة",
];

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <button onClick={handleCopy} className="p-1.5 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors" title="نسخ">
      {copied ? <Check className="w-3.5 h-3.5 text-primary" /> : <Copy className="w-3.5 h-3.5 text-muted-foreground" />}
    </button>
  );
}

function getPaymentIcon(method: string) {
  const lower = method.toLowerCase();
  if (lower.includes("بنك") || lower.includes("iban")) return <Building2 className="w-5 h-5" />;
  if (lower.includes("فيزا") || lower.includes("ماستر") || lower.includes("كارد")) return <CreditCard className="w-5 h-5" />;
  return <Smartphone className="w-5 h-5" />;
}

const Donations = () => {
  const navigate = useNavigate();
  const [settings, setSettings] = useState<DonationSetting[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from("donation_settings").select("*").order("sort_order").then(({ data }) => {
      setSettings((data as DonationSetting[]) || []);
      setLoading(false);
    });
  }, []);

  const sectionIds = ["churches", "humanitarian", "app"];

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <header className="sticky top-0 z-30 bg-card/90 backdrop-blur-lg border-b border-border/40">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-full bg-secondary flex items-center justify-center">
            <ArrowRight className="w-4 h-4 text-foreground" />
          </button>
          <h1 className="text-base font-bold text-foreground">الدعم والتبرعات</h1>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-6 space-y-6">
        {/* Motto */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-center py-4">
          <p className="text-lg font-semibold text-accent-foreground/80 italic leading-relaxed">
            "كن أداة بسيطة… توصل رسالة للأبدية"
          </p>
          <div className="w-16 h-0.5 bg-accent/40 mx-auto mt-3 rounded-full" />
        </motion.div>

        <div className="bg-secondary/60 rounded-2xl p-3 text-center">
          <p className="text-xs text-muted-foreground leading-relaxed">
            🔒 كل تبرع يذهب مباشرة للقسم المختار فقط — حسابات منفصلة لكل قسم لضمان الشفافية والثقة.
          </p>
        </div>

        <Tabs defaultValue="churches" className="w-full">
          <TabsList className="w-full h-auto flex-wrap gap-1 bg-secondary/50 p-1 rounded-2xl">
            {sectionIds.map((id) => (
              <TabsTrigger key={id} value={id}
                className="flex-1 text-xs py-2 rounded-xl data-[state=active]:bg-card data-[state=active]:shadow-sm">
                {sectionMeta[id].title}
              </TabsTrigger>
            ))}
          </TabsList>

          <AnimatePresence mode="wait">
            {sectionIds.map((sectionId) => {
              const meta = sectionMeta[sectionId];
              const payments = settings.filter(s => s.section === sectionId);

              return (
                <TabsContent key={sectionId} value={sectionId} className="mt-4">
                  <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
                    transition={{ duration: 0.25 }} className="space-y-4">
                    <Card className="border-border/40 shadow-card">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className={`w-11 h-11 rounded-2xl ${meta.color} flex items-center justify-center shrink-0`}>
                            {meta.icon}
                          </div>
                          <div>
                            <h2 className="text-sm font-bold text-foreground mb-1">{meta.title}</h2>
                            <p className="text-xs text-muted-foreground leading-relaxed">{meta.description}</p>
                          </div>
                        </div>

                        {sectionId === "app" && (
                          <div className="mt-3 pt-3 border-t border-border/30">
                            <p className="text-xs font-medium text-foreground mb-2">يُستخدم الدعم في:</p>
                            <ul className="space-y-1.5">
                              {usageItems.map((item, i) => (
                                <li key={i} className="flex items-center gap-2 text-xs text-muted-foreground">
                                  <span className="w-1.5 h-1.5 rounded-full bg-accent shrink-0" />
                                  {item}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {sectionId === "humanitarian" && (
                          <div className="mt-3 pt-3 border-t border-border/30 space-y-2">
                            <p className="text-xs font-medium text-foreground">أمثلة على المساعدات:</p>
                            {["مساعدة أسرة محتاجة", "دعم خدمة اجتماعية", "مساعدة طبية"].map((c, i) => (
                              <div key={i} className="flex items-center gap-2 text-xs text-muted-foreground">
                                <Heart className="w-3 h-3 text-destructive/60 shrink-0" />
                                {c}
                              </div>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* Payment Methods from DB */}
                    <div className="space-y-2">
                      <h3 className="text-xs font-bold text-foreground px-1">وسائل الدفع</h3>
                      {loading ? (
                        <p className="text-xs text-muted-foreground text-center py-4">جارٍ التحميل...</p>
                      ) : payments.length > 0 ? (
                        payments.map((method, i) => (
                          <motion.div key={method.id} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: i * 0.05 }}>
                            <div className="flex items-center gap-3 p-3 rounded-xl border border-border/50 bg-card">
                              <div className="w-9 h-9 rounded-full bg-secondary flex items-center justify-center text-muted-foreground shrink-0">
                                {getPaymentIcon(method.payment_method)}
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-xs text-muted-foreground">{method.label}</p>
                                <p className="text-sm font-semibold text-foreground truncate" dir="ltr">{method.details}</p>
                              </div>
                              <CopyButton text={method.details} />
                            </div>
                          </motion.div>
                        ))
                      ) : (
                        <p className="text-xs text-muted-foreground text-center py-6">
                          لم يتم إضافة وسائل دفع لهذا القسم بعد
                        </p>
                      )}
                    </div>

                    <p className="text-[10px] text-muted-foreground/70 text-center px-4 leading-relaxed">
                      جميع التبرعات في هذا القسم تذهب لحساب "{meta.title}" فقط ولا يتم خلطها مع أقسام أخرى.
                    </p>
                  </motion.div>
                </TabsContent>
              );
            })}
          </AnimatePresence>
        </Tabs>
      </main>
    </div>
  );
};

export default Donations;
