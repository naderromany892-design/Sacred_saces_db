import { useMemo, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Search, Heart, Church as ChurchIcon, MapPin, Plus, Pencil, Trash2, MapPinned } from "lucide-react";
import { useFavorites } from "@/hooks/useFavorites";
import { useChurchStore } from "@/hooks/useChurchStore";
import { useSubRegions } from "@/hooks/useSubRegions";
import { isAdminSession } from "@/hooks/useAuth";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import type { Church } from "@/types/church";
import { getDefaultChurchImage, detectSaint } from "@/lib/churchImages";

const ChurchList = () => {
  const { governorate, subRegion } = useParams<{ governorate: string; subRegion?: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const { toggleFavorite, isFavorite } = useFavorites();
  const { churches: allChurches, addChurch, updateChurch, deleteChurch } = useChurchStore();
  const isAdmin = isAdminSession();

  const decodedGov = decodeURIComponent(governorate || "");
  const decodedSub = subRegion ? decodeURIComponent(subRegion) : "";
  const { subRegions } = useSubRegions(decodedGov);


  const churches = useMemo(() => {
    let list = allChurches.filter((c) => c.governorate === decodedGov);
    if (decodedSub) {
      // Inside a specific sub-region: show only churches of that sub-region
      list = list.filter((c) => (c.subRegion || "") === decodedSub);
    } else {
      // On the main governorate page: hide churches that belong to any sub-region.
      // Those are reachable only via the "توابع" button → sub-region page.
      list = list.filter((c) => !c.subRegion);
    }
    if (search) list = list.filter((c) => c.name.includes(search) || c.city.includes(search));
    return list;
  }, [decodedGov, decodedSub, search, allChurches]);

  // Dialog form state (add or edit)
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [city, setCity] = useState("");
  const [address, setAddress] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [chosenSub, setChosenSub] = useState<string>("");

  // Delete confirm
  const [deleteTarget, setDeleteTarget] = useState<Church | null>(null);

  const resetForm = () => {
    setEditingId(null);
    setName(""); setCity(""); setAddress(""); setImageUrl("");
    setChosenSub(decodedSub || "");
  };

  const openAdd = () => {
    resetForm();
    setOpen(true);
  };

  const openEdit = (c: Church) => {
    setEditingId(c.id);
    setName(c.name);
    setCity(c.city);
    setAddress(c.address);
    setImageUrl(c.imageUrl || "");
    setChosenSub(c.subRegion || "");
    setOpen(true);
  };

  const handleSave = () => {
    if (!name.trim() || !address.trim()) {
      toast({ title: "أدخل اسم الكنيسة والعنوان", variant: "destructive" });
      return;
    }
    const finalImage = imageUrl.trim() || getDefaultChurchImage(name.trim());
    if (editingId) {
      updateChurch(editingId, {
        name: name.trim(),
        city: city.trim() || decodedGov,
        address: address.trim(),
        imageUrl: finalImage,
        subRegion: chosenSub || undefined,
      });
      toast({ title: "تم تحديث بيانات الكنيسة ✝️" });
    } else {
      addChurch({
        name: name.trim(),
        city: city.trim() || decodedGov,
        address: address.trim(),
        governorate: decodedGov,
        imageUrl: finalImage,
        subRegion: chosenSub || undefined,
      });
      toast({ title: "تمت إضافة الكنيسة ✝️" });
    }
    resetForm();
    setOpen(false);
  };

  const handleConfirmDelete = () => {
    if (!deleteTarget) return;
    deleteChurch(deleteTarget.id);
    toast({ title: `تم حذف ${deleteTarget.name}` });
    setDeleteTarget(null);
  };

  const headerTitle = decodedSub
    ? `كنائس ${decodedSub} — ${decodedGov}`
    : `كنائس ${decodedGov}`;

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <header className="sticky top-0 z-30 bg-card/90 backdrop-blur-lg border-b border-border/40">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
          <button
            onClick={() => decodedSub
              ? navigate(`/governorate/${encodeURIComponent(decodedGov)}/subregions`)
              : navigate("/")}
            className="p-1.5 rounded-lg hover:bg-secondary transition-colors"
          >
            <ArrowRight className="w-5 h-5 text-foreground" />
          </button>
          <div className="flex-1 min-w-0">
            <h1 className="text-base font-bold text-foreground truncate">{headerTitle}</h1>
            <p className="text-[10px] text-muted-foreground">{churches.length} كنيسة</p>
          </div>
          {isAdmin && (
            <Button size="sm" onClick={openAdd} className="rounded-xl gap-1 h-8 px-3">
              <Plus className="w-3.5 h-3.5" />
              <span className="text-xs">إضافة</span>
            </Button>
          )}
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-5 space-y-4">
        {/* Sub-regions CTA — only on the main governorate page (not when filtering by sub) */}
        {!decodedSub && (
          <button
            onClick={() => navigate(`/governorate/${encodeURIComponent(decodedGov)}/subregions`)}
            className="w-full rounded-2xl p-4 flex items-center gap-3 text-right
                       bg-gradient-to-l from-primary via-primary to-accent
                       text-primary-foreground shadow-card hover:shadow-card-hover
                       transition-all active:scale-[0.99]"
          >
            <div className="w-11 h-11 rounded-xl bg-primary-foreground/15 flex items-center justify-center backdrop-blur-sm">
              <MapPinned className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-bold">توابع {decodedGov}</p>
              <p className="text-[11px] opacity-90 leading-relaxed">
                {isAdmin && subRegions.length === 0
                  ? "أضف المراكز التابعة لهذه المحافظة"
                  : subRegions.length > 0
                    ? `${subRegions.length} مركز/قرية — اضغط للتصفح`
                    : "القرى والمراكز التابعة للمحافظة"}
              </p>
            </div>
            <ArrowRight className="w-5 h-5 rotate-180 opacity-90" />
          </button>
        )}

        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="ابحث عن كنيسة..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-9 bg-card border-border/50 rounded-xl h-10 text-sm"
          />
        </div>

        {isAdmin && (
          <button
            onClick={openAdd}
            className="w-full rounded-2xl border-2 border-dashed border-primary/40 bg-primary/5 hover:bg-primary/10 transition-colors p-4 flex items-center justify-center gap-2 text-primary font-bold text-sm"
          >
            <Plus className="w-4 h-4" />
            {decodedSub
              ? `إضافة كنيسة في ${decodedSub}`
              : `إضافة كنيسة جديدة في ${decodedGov}`}
          </button>
        )}

        <div className="space-y-3">
          {churches.map((church, i) => {
            const displayImg = church.imageUrl || getDefaultChurchImage(church.name);
            const saint = detectSaint(church.name);
            return (
              <motion.div
                key={church.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.05, 0.3), duration: 0.3 }}
                className="bg-card rounded-2xl shadow-card hover:shadow-card-hover transition-all duration-300 overflow-hidden"
              >
                <button
                  onClick={() => navigate(`/church/${church.id}`)}
                  className="w-full flex gap-3 p-4 text-right"
                >
                  <div className="relative w-16 h-16 rounded-xl overflow-hidden shrink-0 bg-secondary">
                    <img src={displayImg} alt={church.name} className="w-full h-full object-cover" />
                    {saint && (
                      <span className="absolute -bottom-1 -left-1 w-7 h-7 rounded-full bg-card border-2 border-card shadow flex items-center justify-center text-base">
                        {saint.emoji}
                      </span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0 space-y-1">
                    <h3 className="text-sm font-bold text-foreground truncate">{church.name}</h3>
                    <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                      <MapPin className="w-3 h-3 shrink-0" />
                      <span className="truncate">{church.address}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <p className="text-[10px] text-accent font-semibold">{church.activities.length} نشاط</p>
                      {church.subRegion && (
                        <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded-full font-semibold">
                          {church.subRegion}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
                <div className="px-4 pb-3 flex items-center justify-between gap-2">
                  <button
                    onClick={(e) => { e.stopPropagation(); toggleFavorite(church.id); }}
                    className="p-1.5 rounded-full hover:bg-secondary transition-colors"
                    aria-label="مفضلة"
                  >
                    <Heart
                      className={`w-4 h-4 transition-colors ${isFavorite(church.id) ? "fill-red-500 text-red-500" : "text-muted-foreground"}`}
                    />
                  </button>
                  {isAdmin && (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={(e) => { e.stopPropagation(); openEdit(church); }}
                        className="p-1.5 rounded-full hover:bg-secondary transition-colors text-primary"
                        aria-label="تعديل"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); setDeleteTarget(church); }}
                        className="p-1.5 rounded-full hover:bg-destructive/10 transition-colors text-destructive"
                        aria-label="حذف"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        {churches.length === 0 && (
          <div className="text-center py-12">
            <ChurchIcon className="w-10 h-10 mx-auto mb-3 text-muted-foreground/25" />
            <p className="text-sm text-muted-foreground">لا توجد كنائس</p>
            {isAdmin && (
              <p className="text-[11px] text-muted-foreground mt-2">اضغط "إضافة كنيسة جديدة" لإنشاء أول كنيسة</p>
            )}
          </div>
        )}
      </main>

      {/* Add / Edit Dialog */}
      <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) resetForm(); }}>
        <DialogContent dir="rtl" className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-sm">
              {editingId ? `تعديل بيانات الكنيسة` : `إضافة كنيسة في ${decodedSub || decodedGov}`}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Input placeholder="اسم الكنيسة *" value={name} onChange={(e) => setName(e.target.value)} className="rounded-xl" />
            <Input placeholder="المدينة / الحي" value={city} onChange={(e) => setCity(e.target.value)} className="rounded-xl" />
            <Input placeholder="العنوان التفصيلي *" value={address} onChange={(e) => setAddress(e.target.value)} className="rounded-xl" />
            {subRegions.length > 0 && (
              <div>
                <label className="text-[11px] text-muted-foreground mb-1 block">التابع (اختياري)</label>
                <select
                  value={chosenSub}
                  onChange={(e) => setChosenSub(e.target.value)}
                  className="w-full bg-background border border-input rounded-xl px-3 py-2 text-sm"
                  dir="rtl"
                >
                  <option value="">— بدون تابع —</option>
                  {subRegions.map((s) => (
                    <option key={s.id} value={s.name}>{s.name}</option>
                  ))}
                </select>
              </div>
            )}
            <Input placeholder="رابط صورة (اختياري — صورة افتراضية ستُستخدم)" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} className="rounded-xl" dir="ltr" />
          </div>
          <DialogFooter>
            <Button onClick={handleSave} className="w-full rounded-xl">
              {editingId ? "حفظ التعديلات" : "حفظ الكنيسة"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف الكنيسة؟</AlertDialogTitle>
            <AlertDialogDescription>
              هل أنت متأكد من حذف "{deleteTarget?.name}"؟ لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default ChurchList;
