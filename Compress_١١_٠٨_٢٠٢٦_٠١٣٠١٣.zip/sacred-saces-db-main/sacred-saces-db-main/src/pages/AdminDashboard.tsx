import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  LogOut, Plus, Check, Clock, MapPin, Trash2, Settings,
  Church as ChurchIcon, CheckCircle2, AlertCircle, Key, ToggleLeft, ToggleRight,
  CreditCard, AlertTriangle, Lock, HandHeart
} from "lucide-react";
import AdminActivityRequests from "@/components/AdminActivityRequests";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { isAdminSession, getAdminCode, getAccessCode, clearSession } from "@/hooks/useAuth";
import { GOVERNORATES, DAYS, ACTIVITY_TYPES, type DayName, type ActivityType } from "@/types/church";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger
} from "@/components/ui/alert-dialog";

interface Activity {
  id: string; day: string; activity_type: string; time: string; sort_time: string;
  location: string | null; status: string; current_confirmations: number;
  confirmations_needed: number; created_at: string;
}
interface DbChurch { id: string; name: string; governorate: string; }
interface DonationSetting {
  id: string; section: string; payment_method: string; label: string; details: string; sort_order: number;
}

const STEPS = ["المحافظة", "الكنيسة", "اليوم", "إضافة نشاط"];
const SECTIONS = [
  { id: "churches", label: "دعم الكنائس" },
  { id: "humanitarian", label: "المساعدات الإنسانية" },
  { id: "app", label: "دعم التطبيق" },
];

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const isAdmin = isAdminSession();
  const adminCode = getAdminCode();
  const accessCode = getAccessCode();

  useEffect(() => {
    if (!accessCode) navigate("/");
  }, [accessCode]);

  const [activeTab, setActiveTab] = useState<"activities" | "settings" | "donations" | "requests">("activities");

  // Activity stepper
  const [step, setStep] = useState(0);
  const [selectedGov, setSelectedGov] = useState("");
  const [selectedChurchId, setSelectedChurchId] = useState("");
  const [selectedDay, setSelectedDay] = useState<DayName>("الأحد");
  const [activityType, setActivityType] = useState<ActivityType>("قداس");
  const [hours, setHours] = useState("08");
  const [minutes, setMinutes] = useState("00");
  const [period, setPeriod] = useState<"ص" | "م">("ص");
  const [location, setLocation] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const [churches, setChurches] = useState<DbChurch[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loadingActivities, setLoadingActivities] = useState(false);

  // Settings
  const [settingsMode, setSettingsMode] = useState<string>("global");
  const [newGlobalPassword, setNewGlobalPassword] = useState("");
  const [allChurches, setAllChurches] = useState<DbChurch[]>([]);
  const [churchPasswords, setChurchPasswords] = useState<Record<string, string>>({});
  const [savingSettings, setSavingSettings] = useState(false);
  const [currentAdminCode, setCurrentAdminCode] = useState("");
  const [newAdminCode, setNewAdminCode] = useState("");

  // Donations
  const [donationSettings, setDonationSettings] = useState<DonationSetting[]>([]);
  const [donationSection, setDonationSection] = useState("churches");
  const [newPaymentMethod, setNewPaymentMethod] = useState("");
  const [newPaymentLabel, setNewPaymentLabel] = useState("");
  const [newPaymentDetails, setNewPaymentDetails] = useState("");
  const [savingDonation, setSavingDonation] = useState(false);

  useEffect(() => {
    if (!selectedGov) return;
    supabase.from("churches").select("id, name, governorate").eq("governorate", selectedGov).then(({ data }) => setChurches(data || []));
  }, [selectedGov]);

  useEffect(() => {
    if (selectedChurchId) loadActivities();
  }, [selectedChurchId]);

  const loadActivities = async () => {
    if (!selectedChurchId || !accessCode) return;
    setLoadingActivities(true);
    if (isAdmin && adminCode) {
      const { data, error } = await supabase.rpc("admin_get_activities", {
        _admin_code: adminCode,
        _church_id: selectedChurchId,
      });
      if (!error && data) {
        setActivities((data as any[]).map((a: any) => ({
          id: a.act_id, day: a.act_day, activity_type: a.act_type, time: a.act_time,
          sort_time: a.act_sort_time, location: a.act_location, status: a.act_status,
          current_confirmations: a.act_confirmations, confirmations_needed: a.act_needed,
          created_at: a.act_created_at,
        })));
      }
    } else {
      const { data, error } = await supabase.rpc("supervisor_get_activities", {
        _password: accessCode,
        _church_id: selectedChurchId,
      });
      if (!error && data) {
        setActivities((data as any[]).map((a: any) => ({
          id: a.act_id, day: a.act_day, activity_type: a.act_type, time: a.act_time,
          sort_time: a.act_sort_time, location: a.act_location, status: a.act_status,
          current_confirmations: a.act_confirmations, confirmations_needed: a.act_needed,
          created_at: a.act_created_at,
        })));
      }
    }
    setLoadingActivities(false);
  };

  // Load settings
  useEffect(() => {
    if (!isAdmin || activeTab !== "settings") return;
    const load = async () => {
      const { data: mode } = await supabase.rpc("get_password_mode");
      if (mode) setSettingsMode(mode as string);
      const { data: ch } = await supabase.from("churches").select("id, name, governorate").order("name");
      setAllChurches(ch || []);
    };
    load();
  }, [isAdmin, activeTab]);

  // Load donations
  useEffect(() => {
    if (!isAdmin || activeTab !== "donations") return;
    loadDonationSettings();
  }, [isAdmin, activeTab]);

  const loadDonationSettings = async () => {
    const { data } = await supabase.from("donation_settings").select("*").order("sort_order");
    setDonationSettings((data as DonationSetting[]) || []);
  };

  const selectedChurch = useMemo(() => churches.find(c => c.id === selectedChurchId), [churches, selectedChurchId]);
  const pendingActivities = useMemo(() => activities.filter(a => a.status === "pending"), [activities]);
  const dayActivities = useMemo(
    () => activities.filter(a => a.day === selectedDay).sort((a, b) => a.sort_time.localeCompare(b.sort_time)),
    [activities, selectedDay]
  );

  const formatTime = () => {
    const h = parseInt(hours);
    const displayH = h === 0 ? 12 : h > 12 ? h - 12 : h;
    return `${displayH}:${minutes} ${period}`;
  };

  const formatSortTime = () => {
    let h = parseInt(hours);
    if (period === "م" && h < 12) h += 12;
    if (period === "ص" && h === 12) h = 0;
    return `${String(h).padStart(2, "0")}:${minutes}`;
  };

  const handleAddActivity = async () => {
    if (!selectedChurchId || !accessCode) return;
    setSubmitting(true);
    if (isAdmin && adminCode) {
      const { error } = await supabase.rpc("admin_add_activity", {
        _admin_code: adminCode, _church_id: selectedChurchId, _day: selectedDay,
        _activity_type: activityType, _time: formatTime(), _sort_time: formatSortTime(), _location: location || "",
      });
      if (error) toast({ title: "خطأ", description: error.message, variant: "destructive" });
      else { toast({ title: "تمت الإضافة (مؤكد تلقائيًا)" }); setLocation(""); await loadActivities(); }
    } else {
      const { error } = await supabase.rpc("supervisor_add_activity", {
        _password: accessCode, _church_id: selectedChurchId, _day: selectedDay,
        _activity_type: activityType, _time: formatTime(), _sort_time: formatSortTime(), _location: location || "",
      });
      if (error) toast({ title: "خطأ", description: error.message, variant: "destructive" });
      else { toast({ title: "تمت الإضافة" }); setLocation(""); await loadActivities(); }
    }
    setSubmitting(false);
  };

  const handleApprove = async (activityId: string) => {
    if (isAdmin && adminCode) {
      const { error } = await supabase.rpc("admin_approve_activity", { _admin_code: adminCode, _activity_id: activityId });
      if (!error) { toast({ title: "تم التأكيد" }); await loadActivities(); }
    } else if (accessCode) {
      const { error } = await supabase.rpc("supervisor_approve_activity", { _password: accessCode, _activity_id: activityId });
      if (!error) { toast({ title: "تم التأكيد" }); await loadActivities(); }
    }
  };

  const handleDelete = async (activityId: string) => {
    if (isAdmin && adminCode) {
      const { error } = await supabase.rpc("admin_delete_activity", { _admin_code: adminCode, _activity_id: activityId });
      if (!error) { toast({ title: "تم الحذف" }); await loadActivities(); }
    } else if (accessCode) {
      const { error } = await supabase.rpc("supervisor_delete_activity", { _password: accessCode, _activity_id: activityId });
      if (!error) { toast({ title: "تم الحذف" }); await loadActivities(); }
    }
  };

  const handleLogout = () => {
    clearSession();
    navigate("/");
  };

  // Settings handlers
  const handleSaveGlobalPassword = async () => {
    if (!newGlobalPassword || !adminCode) return;
    setSavingSettings(true);
    const { data } = await supabase.rpc("admin_set_global_password", { _admin_code: adminCode, _password: newGlobalPassword });
    setSavingSettings(false);
    if (data) { toast({ title: "تم حفظ الكود الموحد" }); setNewGlobalPassword(""); }
    else toast({ title: "خطأ في الحفظ", variant: "destructive" });
  };

  const handleSaveChurchPassword = async (churchId: string) => {
    const pw = churchPasswords[churchId];
    if (!pw || !adminCode) return;
    setSavingSettings(true);
    const { data } = await supabase.rpc("admin_set_church_password", { _admin_code: adminCode, _church_id: churchId, _password: pw });
    setSavingSettings(false);
    if (data) { toast({ title: "تم حفظ كود الكنيسة" }); setChurchPasswords(p => ({ ...p, [churchId]: "" })); }
    else toast({ title: "خطأ في الحفظ", variant: "destructive" });
  };

  const handleToggleMode = async () => {
    if (!adminCode) return;
    const newMode = settingsMode === "global" ? "per_church" : "global";
    setSavingSettings(true);
    const { data } = await supabase.rpc("admin_set_password_mode", { _admin_code: adminCode, _mode: newMode });
    setSavingSettings(false);
    if (data) { setSettingsMode(newMode); toast({ title: `تم التغيير إلى: ${newMode === "global" ? "كود موحد" : "كود لكل كنيسة"}` }); }
  };

  const handleChangeAdminCode = async () => {
    if (!currentAdminCode || !newAdminCode) return;
    setSavingSettings(true);
    const { data } = await supabase.rpc("change_admin_code", { _current_code: currentAdminCode, _new_code: newAdminCode });
    setSavingSettings(false);
    if (data) {
      sessionStorage.setItem("admin_code", newAdminCode);
      toast({ title: "تم تغيير كود الأدمن بنجاح" });
      setCurrentAdminCode(""); setNewAdminCode("");
    } else {
      toast({ title: "الكود الحالي غير صحيح", variant: "destructive" });
    }
  };

  // Donation handlers
  const handleAddDonationEntry = async () => {
    if (!newPaymentMethod || !newPaymentLabel || !newPaymentDetails || !adminCode) return;
    setSavingDonation(true);
    const { error } = await supabase.rpc("admin_add_donation", {
      _admin_code: adminCode, _section: donationSection,
      _payment_method: newPaymentMethod, _label: newPaymentLabel, _details: newPaymentDetails,
      _sort_order: donationSettings.filter(d => d.section === donationSection).length,
    });
    setSavingDonation(false);
    if (error) toast({ title: "خطأ", description: error.message, variant: "destructive" });
    else { toast({ title: "تمت الإضافة" }); setNewPaymentMethod(""); setNewPaymentLabel(""); setNewPaymentDetails(""); await loadDonationSettings(); }
  };

  const handleDeleteDonationEntry = async (id: string) => {
    if (!adminCode) return;
    const { data } = await supabase.rpc("admin_delete_donation", { _admin_code: adminCode, _donation_id: id });
    if (data) { toast({ title: "تم الحذف" }); await loadDonationSettings(); }
  };

  if (!accessCode) return null;
  const sectionDonations = donationSettings.filter(d => d.section === donationSection);

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <header className="sticky top-0 z-30 bg-card/90 backdrop-blur-lg border-b border-border/40">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <ChurchIcon className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-foreground">
                {isAdmin ? "لوحة الأدمن" : "لوحة المشرف"}
              </h1>
              <p className="text-[10px] text-muted-foreground">
                {isAdmin ? "تحكم كامل" : "وضع المشرف"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button variant={activeTab === "requests" ? "default" : "ghost"} size="icon"
              onClick={() => setActiveTab(activeTab === "requests" ? "activities" : "requests")}>
              <HandHeart className="w-4 h-4" />
            </Button>
            {isAdmin && (
              <>
                <Button variant={activeTab === "donations" ? "default" : "ghost"} size="icon"
                  onClick={() => setActiveTab(activeTab === "donations" ? "activities" : "donations")}>
                  <CreditCard className="w-4 h-4" />
                </Button>
                <Button variant={activeTab === "settings" ? "default" : "ghost"} size="icon"
                  onClick={() => setActiveTab(activeTab === "settings" ? "activities" : "settings")}>
                  <Settings className="w-4 h-4" />
                </Button>
              </>
            )}

            <Button variant="ghost" size="icon" onClick={handleLogout}>
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-5 space-y-5">
        {activeTab === "requests" && <AdminActivityRequests />}


        {/* SETTINGS TAB */}
        {isAdmin && activeTab === "settings" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            {/* Change Admin Code */}
            <div className="bg-card rounded-2xl shadow-card p-5 space-y-4">
              <h2 className="text-sm font-bold text-foreground flex items-center gap-2">
                <Lock className="w-4 h-4 text-primary" />
                تغيير كود الأدمن
              </h2>
              <Input value={currentAdminCode} onChange={(e) => setCurrentAdminCode(e.target.value)}
                placeholder="الكود الحالي" type="password" className="rounded-xl" />
              <Input value={newAdminCode} onChange={(e) => setNewAdminCode(e.target.value)}
                placeholder="الكود الجديد" className="rounded-xl" />
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button disabled={savingSettings || !currentAdminCode || !newAdminCode} className="w-full rounded-xl">
                    تغيير الكود
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent dir="rtl">
                  <AlertDialogHeader>
                    <AlertDialogTitle>تأكيد تغيير كود الأدمن</AlertDialogTitle>
                    <AlertDialogDescription>هل أنت متأكد من تغيير كود الأدمن؟</AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>إلغاء</AlertDialogCancel>
                    <AlertDialogAction onClick={handleChangeAdminCode}>تأكيد</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>

            {/* Supervisor Codes */}
            <div className="bg-card rounded-2xl shadow-card p-5 space-y-4">
              <h2 className="text-sm font-bold text-foreground flex items-center gap-2">
                <Key className="w-4 h-4 text-primary" />
                أكواد المشرفين
              </h2>
              <p className="text-[10px] text-muted-foreground">
                أنت المسؤول الوحيد عن تحديد وتغيير أكواد الدخول.
              </p>

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <div className="flex items-center justify-between p-3 bg-secondary/30 rounded-xl cursor-pointer hover:bg-secondary/50 transition-colors">
                    <div>
                      <p className="text-xs font-semibold text-foreground">
                        {settingsMode === "global" ? "كود موحد لجميع الكنائس" : "كود لكل كنيسة"}
                      </p>
                      <p className="text-[10px] text-muted-foreground">اضغط للتبديل</p>
                    </div>
                    {settingsMode === "global" ? <ToggleLeft className="w-8 h-8 text-muted-foreground" /> : <ToggleRight className="w-8 h-8 text-primary" />}
                  </div>
                </AlertDialogTrigger>
                <AlertDialogContent dir="rtl">
                  <AlertDialogHeader>
                    <AlertDialogTitle className="flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5 text-accent" />
                      تأكيد تغيير النظام
                    </AlertDialogTitle>
                    <AlertDialogDescription>
                      هل تريد التبديل إلى {settingsMode === "global" ? "كود لكل كنيسة" : "كود موحد"}؟
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>إلغاء</AlertDialogCancel>
                    <AlertDialogAction onClick={handleToggleMode}>تأكيد</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>

              {settingsMode === "global" && (
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-foreground">الكود الموحد</label>
                  <div className="flex gap-2">
                    <Input value={newGlobalPassword} onChange={(e) => setNewGlobalPassword(e.target.value)}
                      placeholder="أدخل الكود الجديد" className="rounded-xl flex-1" />
                    <Button onClick={handleSaveGlobalPassword} disabled={savingSettings || !newGlobalPassword} className="rounded-xl px-4">حفظ</Button>
                  </div>
                  <p className="text-[10px] text-destructive/80 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" /> يجب تحديد كود من هنا أولاً
                  </p>
                </div>
              )}

              {settingsMode === "per_church" && (
                <div className="space-y-3">
                  <label className="text-xs font-semibold text-foreground">أكواد الكنائس</label>
                  {allChurches.map((c) => (
                    <div key={c.id} className="flex items-center gap-2">
                      <span className="text-xs text-foreground flex-1 truncate">{c.name}</span>
                      <Input value={churchPasswords[c.id] || ""} onChange={(e) => setChurchPasswords(p => ({ ...p, [c.id]: e.target.value }))}
                        placeholder="الكود" className="rounded-xl w-28" />
                      <Button size="sm" onClick={() => handleSaveChurchPassword(c.id)}
                        disabled={savingSettings || !churchPasswords[c.id]} className="rounded-lg text-xs h-8 px-3">حفظ</Button>
                    </div>
                  ))}
                  {allChurches.length === 0 && <p className="text-xs text-muted-foreground text-center py-4">لا توجد كنائس</p>}
                </div>
              )}
            </div>
          </motion.div>
        )}

        {/* DONATIONS TAB */}
        {isAdmin && activeTab === "donations" && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-5">
            <div className="bg-card rounded-2xl shadow-card p-5 space-y-4">
              <h2 className="text-sm font-bold text-foreground flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-primary" /> إدارة التبرعات
              </h2>
              <div className="flex gap-2">
                {SECTIONS.map((s) => (
                  <button key={s.id} onClick={() => setDonationSection(s.id)}
                    className={`flex-1 py-2 px-2 rounded-xl text-[11px] font-semibold transition-all ${
                      donationSection === s.id ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"
                    }`}>{s.label}</button>
                ))}
              </div>

              {sectionDonations.length > 0 ? (
                <div className="space-y-2">
                  {sectionDonations.map((d) => (
                    <div key={d.id} className="flex items-center gap-2 p-3 bg-secondary/30 rounded-xl">
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-foreground">{d.payment_method}</p>
                        <p className="text-[10px] text-muted-foreground">{d.label}</p>
                        <p className="text-xs text-foreground font-mono truncate" dir="ltr">{d.details}</p>
                      </div>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button size="sm" variant="ghost" className="text-destructive h-8 px-2"><Trash2 className="w-3.5 h-3.5" /></Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent dir="rtl">
                          <AlertDialogHeader>
                            <AlertDialogTitle>حذف وسيلة الدفع</AlertDialogTitle>
                            <AlertDialogDescription>هل تريد حذف "{d.payment_method}"؟</AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>إلغاء</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDeleteDonationEntry(d.id)}>حذف</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground text-center py-4">لا توجد بيانات دفع لهذا القسم</p>
              )}

              <div className="border-t border-border/40 pt-4 space-y-3">
                <h3 className="text-xs font-bold text-foreground">إضافة وسيلة دفع</h3>
                <Input value={newPaymentMethod} onChange={(e) => setNewPaymentMethod(e.target.value)} placeholder="اسم الوسيلة (إنستاباي)" className="rounded-xl" />
                <Input value={newPaymentLabel} onChange={(e) => setNewPaymentLabel(e.target.value)} placeholder="الوصف" className="rounded-xl" />
                <Input value={newPaymentDetails} onChange={(e) => setNewPaymentDetails(e.target.value)} placeholder="البيانات (الرقم أو IBAN)" className="rounded-xl" dir="ltr" />
                <Button onClick={handleAddDonationEntry} disabled={savingDonation || !newPaymentMethod || !newPaymentLabel || !newPaymentDetails}
                  className="w-full rounded-xl h-10 text-sm font-bold gap-2">
                  <Plus className="w-4 h-4" /> إضافة
                </Button>
              </div>
            </div>
          </motion.div>
        )}

        {/* ACTIVITIES TAB */}
        {activeTab === "activities" && (
          <>
            <div className="flex items-center gap-1">
              {STEPS.map((s, i) => (
                <div key={s} className="flex-1">
                  <button onClick={() => { if (i < step) setStep(i); }}
                    className={`w-full h-1.5 rounded-full transition-colors ${i <= step ? "bg-primary" : "bg-border"}`} />
                </div>
              ))}
            </div>
            <p className="text-xs font-bold text-center text-foreground">الخطوة {step + 1}: {STEPS[step]}</p>

            <AnimatePresence mode="wait">
              {step === 0 && (
                <motion.div key="gov" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="grid grid-cols-2 gap-2">
                  {GOVERNORATES.map((g) => (
                    <button key={g} onClick={() => { setSelectedGov(g); setStep(1); }}
                      className={`p-3 rounded-xl text-xs font-semibold transition-all ${
                        selectedGov === g ? "bg-primary text-primary-foreground shadow-md" : "bg-card text-foreground shadow-card hover:shadow-card-hover"
                      }`}>{g}</button>
                  ))}
                </motion.div>
              )}

              {step === 1 && (
                <motion.div key="church" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-3">
                  {churches.length === 0 ? (
                    <div className="text-center py-12 bg-card rounded-2xl shadow-card">
                      <ChurchIcon className="w-10 h-10 mx-auto mb-3 text-muted-foreground/25" />
                      <p className="text-sm text-muted-foreground">لا توجد كنائس في {selectedGov}</p>
                    </div>
                  ) : churches.map((c) => (
                    <button key={c.id} onClick={() => { setSelectedChurchId(c.id); setStep(2); }}
                      className={`w-full p-4 rounded-xl text-right text-sm font-semibold transition-all ${
                        selectedChurchId === c.id ? "bg-primary text-primary-foreground shadow-md" : "bg-card text-foreground shadow-card hover:shadow-card-hover"
                      }`}>
                      <div className="flex items-center gap-2"><ChurchIcon className="w-5 h-5 shrink-0" />{c.name}</div>
                    </button>
                  ))}
                  <Button variant="outline" className="w-full rounded-xl" onClick={() => setStep(0)}>رجوع</Button>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div key="day" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
                  <p className="text-xs text-muted-foreground text-center">
                    الكنيسة: <span className="font-bold text-foreground">{selectedChurch?.name}</span>
                  </p>
                  <div className="grid grid-cols-4 gap-2">
                    {DAYS.map((d) => (
                      <button key={d} onClick={() => { setSelectedDay(d); setStep(3); }}
                        className={`p-3 rounded-xl text-xs font-semibold transition-all ${
                          selectedDay === d ? "bg-accent text-accent-foreground shadow-md" : "bg-card text-foreground shadow-card hover:shadow-card-hover"
                        }`}>{d}</button>
                    ))}
                  </div>

                  {pendingActivities.length > 0 && (
                    <div className="space-y-2">
                      <h3 className="text-xs font-bold text-foreground flex items-center gap-1.5">
                        <AlertCircle className="w-3.5 h-3.5 text-accent" />
                        في انتظار التأكيد ({pendingActivities.length})
                      </h3>
                      {pendingActivities.map((a) => (
                        <div key={a.id} className="bg-card rounded-xl shadow-card p-3 flex items-center justify-between">
                          <div className="text-xs space-y-0.5">
                            <p className="font-semibold text-foreground">{a.activity_type} — {a.day}</p>
                            <p className="text-muted-foreground">{a.time} {a.location && `• ${a.location}`}</p>
                          </div>
                          <div className="flex items-center gap-1">
                            <Button size="sm" variant="outline" className="rounded-lg text-[10px] h-7 px-2 gap-0.5 border-accent text-accent hover:bg-accent hover:text-accent-foreground"
                              onClick={() => handleApprove(a.id)}><Check className="w-3 h-3" /> تأكيد</Button>
                            <Button size="sm" variant="ghost" className="rounded-lg text-[10px] h-7 px-1.5 text-destructive"
                              onClick={() => handleDelete(a.id)}><Trash2 className="w-3 h-3" /></Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  <Button variant="outline" className="w-full rounded-xl" onClick={() => setStep(1)}>رجوع</Button>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div key="add" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-4">
                  <p className="text-xs text-muted-foreground text-center">
                    <span className="font-bold text-foreground">{selectedChurch?.name}</span> — يوم <span className="font-bold text-accent">{selectedDay}</span>
                  </p>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-foreground">نوع النشاط</label>
                    <div className="grid grid-cols-3 gap-2">
                      {ACTIVITY_TYPES.map((t) => (
                        <button key={t} onClick={() => setActivityType(t)}
                          className={`p-2.5 rounded-xl text-[11px] font-semibold transition-all ${
                            activityType === t ? "bg-primary text-primary-foreground shadow-md" : "bg-card text-foreground shadow-card"
                          }`}>{t}</button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-foreground flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-accent" /> الوقت
                    </label>
                    <div className="flex items-center gap-2">
                      <select value={hours} onChange={(e) => setHours(e.target.value)}
                        className="flex-1 h-10 rounded-xl bg-card border border-border text-sm text-center text-foreground">
                        {Array.from({ length: 12 }, (_, i) => String(i + 1).padStart(2, "0")).map((h) => (
                          <option key={h} value={h}>{h}</option>
                        ))}
                      </select>
                      <span className="text-lg font-bold text-foreground">:</span>
                      <select value={minutes} onChange={(e) => setMinutes(e.target.value)}
                        className="flex-1 h-10 rounded-xl bg-card border border-border text-sm text-center text-foreground">
                        {["00", "15", "30", "45"].map((m) => <option key={m} value={m}>{m}</option>)}
                      </select>
                      <div className="flex rounded-xl overflow-hidden border border-border">
                        <button onClick={() => setPeriod("ص")} className={`px-3 py-2 text-xs font-semibold transition-colors ${period === "ص" ? "bg-primary text-primary-foreground" : "bg-card text-foreground"}`}>ص</button>
                        <button onClick={() => setPeriod("م")} className={`px-3 py-2 text-xs font-semibold transition-colors ${period === "م" ? "bg-primary text-primary-foreground" : "bg-card text-foreground"}`}>م</button>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-foreground flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-accent" /> المكان (اختياري)
                    </label>
                    <Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="مثال: الكنيسة الكبرى" className="rounded-xl" />
                  </div>

                  <Button className="w-full rounded-xl h-12 text-sm font-bold gap-2" onClick={handleAddActivity} disabled={submitting}>
                    <Plus className="w-4 h-4" /> {submitting ? "جارٍ الإضافة..." : "إضافة النشاط"}
                  </Button>

                  {dayActivities.length > 0 && (
                    <div className="space-y-2 pt-2">
                      <h3 className="text-xs font-bold text-foreground">أنشطة يوم {selectedDay}</h3>
                      {dayActivities.map((a) => (
                        <div key={a.id} className="bg-card rounded-xl shadow-card p-3 flex items-center justify-between">
                          <div className="text-xs space-y-0.5">
                            <p className="font-semibold text-foreground">{a.activity_type}</p>
                            <p className="text-muted-foreground">{a.time} {a.location && `• ${a.location}`}</p>
                          </div>
                          <div className="flex items-center gap-1.5">
                            {a.status === "approved" ? (
                              <span className="flex items-center gap-1 text-[10px] font-semibold text-primary">
                                <CheckCircle2 className="w-3.5 h-3.5" /> مؤكد
                              </span>
                            ) : (
                              <Button size="sm" variant="outline" className="rounded-lg text-[10px] h-7 px-2 gap-0.5 border-accent text-accent"
                                onClick={() => handleApprove(a.id)}><Check className="w-3 h-3" /> تأكيد</Button>
                            )}
                            <Button size="sm" variant="ghost" className="rounded-lg text-[10px] h-7 px-1.5 text-destructive"
                              onClick={() => handleDelete(a.id)}><Trash2 className="w-3 h-3" /></Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  <Button variant="outline" className="w-full rounded-xl" onClick={() => setStep(2)}>رجوع</Button>
                </motion.div>
              )}
            </AnimatePresence>
          </>
        )}
      </main>
    </div>
  );
};

export default AdminDashboard;
