import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Heart, Church as ChurchIcon, MapPin, Star } from "lucide-react";
import { sampleChurches } from "@/data/churches";
import { useFavorites } from "@/hooks/useFavorites";

const Favorites = () => {
  const navigate = useNavigate();
  const { favorites, toggleFavorite, isFavorite } = useFavorites();

  const favoriteChurches = useMemo(
    () => sampleChurches.filter((c) => favorites.has(c.id)),
    [favorites]
  );

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <header className="sticky top-0 z-30 bg-card/90 backdrop-blur-lg border-b border-border/40">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate("/")} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
            <ArrowRight className="w-5 h-5 text-foreground" />
          </button>
          <Star className="w-5 h-5 text-accent" />
          <h1 className="text-base font-bold text-foreground">المفضلة</h1>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-5 space-y-3">
        {favoriteChurches.length > 0 ? (
          favoriteChurches.map((church, i) => (
            <motion.div
              key={church.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-card rounded-2xl shadow-card hover:shadow-card-hover transition-all overflow-hidden"
            >
              <button
                onClick={() => navigate(`/church/${church.id}`)}
                className="w-full flex gap-3 p-4 text-right"
              >
                <div className="w-14 h-14 rounded-xl overflow-hidden shrink-0 bg-secondary">
                  {church.imageUrl ? (
                    <img src={church.imageUrl} alt={church.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <ChurchIcon className="w-6 h-6 text-muted-foreground/40" />
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0 space-y-1">
                  <h3 className="text-sm font-bold text-foreground truncate">{church.name}</h3>
                  <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                    <MapPin className="w-3 h-3 shrink-0" />
                    <span className="truncate">{church.address}</span>
                  </div>
                </div>
              </button>
              <div className="px-4 pb-3 flex justify-end">
                <button
                  onClick={() => toggleFavorite(church.id)}
                  className="p-1.5 rounded-full hover:bg-secondary transition-colors"
                >
                  <Heart className="w-4 h-4 fill-red-500 text-red-500" />
                </button>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="text-center py-16">
            <Star className="w-12 h-12 mx-auto mb-3 text-muted-foreground/25" />
            <p className="text-sm text-muted-foreground">لا توجد كنائس في المفضلة</p>
            <p className="text-xs text-muted-foreground mt-1">اضغط ♡ بجانب أي كنيسة لإضافتها</p>
          </div>
        )}
      </main>
    </div>
  );
};

export default Favorites;
