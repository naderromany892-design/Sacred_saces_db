import { useState, useMemo } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, MapPinned, Plus, Pencil, Trash2, Church as ChurchIcon } from "lucide-react";
import { useSubRegions } from "@/hooks/useSubRegions";
import { useChurchStore } from "@/hooks/useChurchStore";
import { isAdminSession } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";

const SubRegions = () => {
  const { governorate } = useParams<{ governorate: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const decodedGov = decodeURIComponent(governorate || "");
  const isAdmin = isAdminSession();
  const { subRegions, addSubRegion, renameSubRegion, removeSubRegion } = useSubRegions(decodedGov);
  const { churches } = useChurchStore();

  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const counts = useMemo(() => {
    const map = new Map<string, number>();
    for (const c of churches) {
      if (c.governorate !== decodedGov) continue;
      const key = (c.subRegion || "").trim();
      if (!key) continue;
      map.set(key, (map.get(key) || 0) + 1);
    }
    return map;
  }, [churches, decodedGov]);

  const openAdd = () => { setEditingId(null); setName(""); setOpen(true); };
  const openEdit = (id: string, current: string) => { setEditingId(id); setName(current); setOpen(true); };

  const handleSave = () => {
    if (!name.trim()) {
      toast({ title: "أدخل اسم التابع", variant: "destructive" });
      return;
    }
    if (editingId) {
      renameSubRegion(editingId, name.trim());
      toast({ title: "تم تحديث التابع" });
    } else {
      addSubRegion(decodedGov, name.trim());
      toast({ title: "تمت إضافة التابع ✝️" });
    }
    setOpen(false);
  };

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <header className="sticky top-0 z-30 bg-card/90 backdrop-blur-lg border-b border-border/40">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
          <button
            onClick={() => navigate(`/governorate/${encodeURIComponent(decodedGov)}`)}
            className="p-1.5 rounded-lg hover:bg-secondary transition-colors"
          >
            <ArrowRight className="w-5 h-5 text-foreground" />
          </button>
          <div className="flex-1">
            <h1 className="text-base font-bold text-foreground">توابع {decodedGov}</h1>
            <p className="text-[10px] text-muted-foreground">{subRegions.length} تابع</p>
          </div>
          {isAdmin && (
            <Button size="sm" onClick={openAdd} className="rounded-xl gap-1 h-8 px-3">
              <Plus className="w-3.5 h-3.5" />
              <span className="text-xs">إضافة</span>
            </Button>
          )}
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-5 space-y-4">
        {isAdmin && (
          <button
            onClick={openAdd}
            className="w-full rounded-2xl border-2 border-dashed border-primary/40 bg-primary/5 hover:bg-primary/10 transition-colors p-4 flex items-center justify-center gap-2 text-primary font-bold text-sm"
          >
            <Plus className="w-4 h-4" />
            إضافة تابع جديد لـ {decodedGov}
          </button>
        )}

        <div className="grid grid-cols-2 gap-3">
          {subRegions.map((sr, i) => (
            <motion.div
              key={sr.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: Math.min(i * 0.04, 0.25), duration: 0.25 }}
              className="bg-card rounded-2xl shadow-card hover:shadow-card-hover transition-all overflow-hidden"
            >
              <button
                onClick={() => navigate(`/governorate/${encodeURIComponent(decodedGov)}/sub/${encodeURIComponent(sr.name)}`)}
                className="w-full p-4 text-center flex flex-col items-center gap-2"
              >
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                  <MapPinned className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-sm font-bold text-foreground truncate w-full">{sr.name}</h3>
                <p className="text-[10px] text-accent font-semibold">
                  {counts.get(sr.name) || 0} كنيسة
                </p>
              </button>
              {isAdmin && (
                <div className="px-3 pb-3 flex items-center justify-center gap-1">
                  <button
                    onClick={() => openEdit(sr.id, sr.name)}
                    className="p-1.5 rounded-full hover:bg-secondary text-primary"
                    aria-label="تعديل"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setDeleteId(sr.id)}
                    className="p-1.5 rounded-full hover:bg-destructive/10 text-destructive"
                    aria-label="حذف"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </motion.div>
          ))}
        </div>

        {subRegions.length === 0 && (
          <div className="text-center py-12">
            <ChurchIcon className="w-10 h-10 mx-auto mb-3 text-muted-foreground/25" />
            <p className="text-sm text-muted-foreground">لا توجد توابع لـ {decodedGov} بعد</p>
            {isAdmin && (
              <p className="text-[11px] text-muted-foreground mt-2">اضغط "إضافة تابع جديد" لبدء إضافة المراكز</p>
            )}
          </div>
        )}
      </main>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent dir="rtl" className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-sm">
              {editingId ? "تعديل اسم التابع" : `إضافة تابع لـ ${decodedGov}`}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Input
              placeholder="اسم التابع (مثل: فايد، أبو صوير)"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="rounded-xl"
            />
          </div>
          <DialogFooter>
            <Button onClick={handleSave} className="w-full rounded-xl">
              {editingId ? "حفظ" : "إضافة"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف التابع؟</AlertDialogTitle>
            <AlertDialogDescription>
              لن تُحذف الكنائس، لكنها لن تظهر تحت هذا التابع بعد الآن.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => { if (deleteId) { removeSubRegion(deleteId); toast({ title: "تم الحذف" }); } setDeleteId(null); }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default SubRegions;
