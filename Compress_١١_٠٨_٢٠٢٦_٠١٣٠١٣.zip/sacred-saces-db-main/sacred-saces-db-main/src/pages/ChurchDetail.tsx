import { useMemo, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, Heart, Church as ChurchIcon, MapPin, Clock, Plus, Trash2, Pencil, Image as ImageIcon, Sparkles } from "lucide-react";
import { useFavorites } from "@/hooks/useFavorites";
import { useChurchStore } from "@/hooks/useChurchStore";
import { isAdminSession } from "@/hooks/useAuth";
import { DAYS, type DayName, type ChurchActivity } from "@/types/church";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { getDefaultChurchImage, detectSaint, getSaintOverride, setSaintOverride } from "@/lib/churchImages";
import { isActivityEnded } from "@/lib/activityStatus";
import { useNowTick } from "@/hooks/useNowTick";
import ReminderButton from "@/components/ReminderButton";

const TODAY_INDEX_TO_DAY: Record<number, DayName> = {
  0: "الأحد", 1: "الاثنين", 2: "الثلاثاء", 3: "الأربعاء",
  4: "الخميس", 5: "الجمعة", 6: "السبت",
};

type ActivityState = "upcoming" | "ongoing" | "ended";

/** قداس ليلي: نشاط قداس يبدأ بعد الساعة 6 مساءً */
export const isNightMass = (a: ChurchActivity): boolean => {
  if (!a.type?.includes("قداس")) return false;
  const [h, m] = a.sortTime.split(":").map((n) => parseInt(n, 10));
  if (Number.isNaN(h)) return false;
  return h * 60 + (m || 0) > 18 * 60;
};


const getActivityState = (a: ChurchActivity, today: DayName, now: Date): ActivityState => {
  if (a.day !== today) return "upcoming";
  const [sh, sm] = a.sortTime.split(":").map((n) => parseInt(n, 10));
  if (Number.isNaN(sh) || Number.isNaN(sm)) return "upcoming";
  const startMin = sh * 60 + sm;
  const nowMin = now.getHours() * 60 + now.getMinutes();
  if (a.endSortTime) {
    const [eh, em] = a.endSortTime.split(":").map((n) => parseInt(n, 10));
    const endMin = eh * 60 + em;
    if (nowMin >= endMin) return "ended";
  }
  // No end time: treat as ongoing for 90 min after start, then ended.
  if (!a.endSortTime && nowMin >= startMin + 90) return "ended";
  if (nowMin >= startMin) return "ongoing";
  return "upcoming";
};

type SlotDraft = {
  type: string;
  day: DayName;
  hours: string;
  minutes: string;
  period: "ص" | "م";
  endHours: string;
  endMinutes: string;
  endPeriod: "ص" | "م";
  hasEnd: boolean;
  location: string;
};

const formatTimeOf = (h: string, m: string, p: "ص" | "م") => {
  const hi = parseInt(h);
  const display = hi === 0 ? 12 : hi > 12 ? hi - 12 : hi;
  return `${display}:${m} ${p}`;
};
const formatSortOf = (h: string, m: string, p: "ص" | "م") => {
  let hi = parseInt(h);
  if (p === "م" && hi < 12) hi += 12;
  if (p === "ص" && hi === 12) hi = 0;
  return `${String(hi).padStart(2, "0")}:${m}`;
};

const parseSort = (sort: string): { hours: string; minutes: string; period: "ص" | "م" } => {
  const [h, m] = sort.split(":");
  const hi = parseInt(h || "0");
  const period: "ص" | "م" = hi >= 12 ? "م" : "ص";
  let display = hi % 12;
  if (display === 0) display = 12;
  return { hours: String(display).padStart(2, "0"), minutes: m || "00", period };
};

const ChurchDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { toggleFavorite, isFavorite } = useFavorites();
  const { churches, addActivity, updateActivity, removeActivity, updateChurch } = useChurchStore();
  const isAdmin = isAdminSession();
  const now = useNowTick(30_000);

  const church = useMemo(() => churches.find((c) => c.id === id), [id, churches]);
  const today: DayName = TODAY_INDEX_TO_DAY[new Date().getDay()];

  const categoriesMap = useMemo(() => {
    if (!church) return new Map<string, ChurchActivity[]>();
    const map = new Map<string, ChurchActivity[]>();
    const order = ["قداس", "تسبحة", "اجتماع"];
    for (const key of order) map.set(key, []);
    for (const a of church.activities) {
      if (!map.has(a.type)) map.set(a.type, []);
      map.get(a.type)!.push(a);
    }
    return map;
  }, [church]);

  const { ongoingToday, upcomingToday, endedToday } = useMemo(() => {
    const ongoing: ChurchActivity[] = [];
    const upcoming: ChurchActivity[] = [];
    const ended: ChurchActivity[] = [];
    if (!church) return { ongoingToday: ongoing, upcomingToday: upcoming, endedToday: ended };
    const list = church.activities
      .filter((a) => a.day === today)
      .sort((a, b) => a.sortTime.localeCompare(b.sortTime));
    for (const a of list) {
      const s = getActivityState(a, today, now);
      if (s === "ended") ended.push(a);
      else if (s === "ongoing") ongoing.push(a);
      else upcoming.push(a);
    }
    return { ongoingToday: ongoing, upcomingToday: upcoming, endedToday: ended };
  }, [church, today, now]);

  const tomorrow: DayName = TODAY_INDEX_TO_DAY[(new Date().getDay() + 1) % 7];
  const tomorrowActivities = useMemo(() => {
    if (!church) return [] as ChurchActivity[];
    return church.activities
      .filter((a) => a.day === tomorrow)
      .sort((a, b) => a.sortTime.localeCompare(b.sortTime));
  }, [church, tomorrow]);

  // Rule: never show tomorrow's activities unless ALL of today's are finished.
  const todayFinished = ongoingToday.length === 0 && upcomingToday.length === 0;
  const upcomingCombined = useMemo(
    () => (todayFinished ? tomorrowActivities : upcomingToday),
    [todayFinished, tomorrowActivities, upcomingToday]
  );
  const upcomingTitle = todayFinished ? "أنشطة الغد" : "أنشطة اليوم القادمة";


  const [openType, setOpenType] = useState<string | null>(null);
  const [mediaOpen, setMediaOpen] = useState(false);
  const [mediaChurchUrl, setMediaChurchUrl] = useState("");
  const [mediaSaintUrl, setMediaSaintUrl] = useState("");

  const churchSaint = useMemo(() => (church ? detectSaint(church.name) : null), [church]);
  const saintOverrideUrl = church ? getSaintOverride(church.id) : null;
  const heroImage = church ? (church.imageUrl || getDefaultChurchImage(church.name)) : "";

  const weeklyForType = useMemo(() => {
    if (!church || !openType) return {} as Record<string, ChurchActivity[]>;
    const result: Record<string, ChurchActivity[]> = {};
    for (const day of DAYS) {
      result[day] = church.activities
        .filter((a) => a.day === day && a.type === openType)
        .sort((a, b) => a.sortTime.localeCompare(b.sortTime));
    }
    return result;
  }, [church, openType]);

  // Generic add/edit slot dialog
  const [slotOpen, setSlotOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<SlotDraft>({
    type: "", day: today, hours: "08", minutes: "00", period: "ص",
    endHours: "10", endMinutes: "00", endPeriod: "ص", hasEnd: false,
    location: "",
  });

  const openAddDialog = (presetType?: string, presetDay?: DayName) => {
    setEditingId(null);
    setDraft({
      type: presetType ?? "",
      day: presetDay ?? today,
      hours: "08", minutes: "00", period: "ص",
      endHours: "10", endMinutes: "00", endPeriod: "ص", hasEnd: false,
      location: "",
    });
    setSlotOpen(true);
  };

  const openEditDialog = (a: ChurchActivity) => {
    const t = parseSort(a.sortTime);
    const e = a.endSortTime ? parseSort(a.endSortTime) : null;
    setEditingId(a.id);
    setDraft({
      type: a.type, day: a.day, hours: t.hours, minutes: t.minutes, period: t.period,
      endHours: e?.hours ?? "10",
      endMinutes: e?.minutes ?? "00",
      endPeriod: e?.period ?? "ص",
      hasEnd: !!a.endSortTime,
      location: a.location || "",
    });
    setSlotOpen(true);
  };

  const handleSaveSlot = () => {
    if (!church || !draft.type.trim()) {
      toast({ title: "أدخل نوع النشاط", variant: "destructive" });
      return;
    }
    const payload: Omit<ChurchActivity, "id"> = {
      day: draft.day,
      type: draft.type.trim() as ChurchActivity["type"],
      time: formatTimeOf(draft.hours, draft.minutes, draft.period),
      sortTime: formatSortOf(draft.hours, draft.minutes, draft.period),
      location: draft.location.trim(),
      endTime: draft.hasEnd ? formatTimeOf(draft.endHours, draft.endMinutes, draft.endPeriod) : undefined,
      endSortTime: draft.hasEnd ? formatSortOf(draft.endHours, draft.endMinutes, draft.endPeriod) : undefined,
    };
    if (editingId) {
      updateActivity(church.id, editingId, payload);
      toast({ title: "تم تعديل الموعد ✏️" });
    } else {
      addActivity(church.id, payload);
      toast({ title: "تمت إضافة الموعد ✝️" });
    }
    setSlotOpen(false);
  };

  const getCategoryIcon = (type: string) => {
    if (type === "قداس") return "⛪";
    if (type === "تسبحة") return "📖";
    if (type === "اجتماع") return "🤝";
    if (type === "خدمة") return "✨";
    if (type.includes("شباب")) return "👥";
    if (type.includes("مدارس")) return "📚";
    return "🕊️";
  };

  if (!church) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center" dir="rtl">
        <div className="text-center">
          <ChurchIcon className="w-12 h-12 mx-auto mb-3 text-muted-foreground/25" />
          <p className="text-muted-foreground">الكنيسة غير موجودة</p>
          <button onClick={() => navigate("/")} className="mt-4 text-sm text-primary underline">العودة</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <header className="sticky top-0 z-30 bg-card/90 backdrop-blur-lg border-b border-border/40">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
            <ArrowRight className="w-5 h-5 text-foreground" />
          </button>
          <h1 className="text-sm font-bold text-foreground truncate flex-1">{church.name}</h1>
          <button onClick={() => toggleFavorite(church.id)} className="p-2 rounded-full hover:bg-secondary transition-colors">
            <Heart className={`w-5 h-5 transition-colors ${isFavorite(church.id) ? "fill-red-500 text-red-500" : "text-muted-foreground"}`} />
          </button>
        </div>
      </header>

      <main className="max-w-lg mx-auto">
        <div className="relative w-full h-40 bg-secondary overflow-hidden">
          <img src={heroImage} alt={church.name} className="w-full h-full object-cover" />
          {isAdmin && (
            <button
              onClick={() => {
                setMediaChurchUrl(church.imageUrl || "");
                setMediaSaintUrl(saintOverrideUrl || "");
                setMediaOpen(true);
              }}
              className="absolute bottom-2 left-2 bg-card/90 backdrop-blur text-foreground rounded-full p-2 shadow-card hover:bg-card transition-colors"
              aria-label="تغيير الصور"
            >
              <ImageIcon className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="px-4 py-5 space-y-5">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-foreground flex-1">{church.name}</h2>
              {churchSaint && (
                <div
                  className="w-9 h-9 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 border border-primary/30 flex items-center justify-center text-lg shrink-0 overflow-hidden"
                  title={churchSaint.name}
                >
                  {saintOverrideUrl ? (
                    <img src={saintOverrideUrl} alt={churchSaint.name} className="w-full h-full object-cover" />
                  ) : (
                    <span>{churchSaint.emoji}</span>
                  )}
                </div>
              )}
            </div>
            {churchSaint && (
              <p className="text-[11px] text-primary font-semibold">شفيع الكنيسة: {churchSaint.name}</p>
            )}
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <MapPin className="w-3.5 h-3.5 text-accent shrink-0" />
              <span>{church.address}</span>
            </div>
          </div>

          {isAdmin && (
            <Button onClick={() => openAddDialog()} className="w-full rounded-xl gap-2">
              <Plus className="w-4 h-4" />
              إضافة نشاط جديد
            </Button>
          )}

          {/* ============ Group 1: أنشطة الغد — elegant white + gold ============ */}
          {upcomingCombined.length > 0 && (
            <section className="space-y-3">
              <div className="flex items-center justify-between px-1">
                <h3 className="text-sm font-semibold flex items-center gap-1.5" style={{ color: "#A16207" }}>
                  <span className="text-base">👑</span>
                  {upcomingTitle}
                </h3>
                <span className="text-[10px] text-neutral-400 font-semibold">{upcomingCombined.length}</span>
              </div>
              <AnimatePresence initial={false}>
                {upcomingCombined.map((a) => {
                  const isTomorrow = a.day === tomorrow;
                  const night = isNightMass(a);
                  return (
                    <motion.div
                      key={a.id}
                      layout
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.97 }}
                      transition={{ duration: 0.3, ease: "easeOut" }}
                      className="rounded-2xl overflow-hidden border-[1.5px]"
                      style={{
                        background: night
                          ? "linear-gradient(180deg, #FEF3C7 0%, #FDE9B0 100%)"
                          : "linear-gradient(180deg, #FFFFFF 0%, #FFFBEB 100%)",
                        borderColor: night ? "#D4AF37" : "#FDE047",
                        boxShadow: "0 10px 24px -12px rgba(253,224,71,0.35), 0 2px 6px rgba(0,0,0,0.03)",
                      }}
                    >
                      <div className="h-1.5 w-full bg-gradient-to-l from-[#FACC15] to-[#D4AF37]" />
                      <div className="p-3.5 flex items-center gap-3">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-[#111827] truncate flex items-center gap-1.5">
                            {night && <span className="text-base leading-none">🌙</span>}
                            {a.type}
                          </p>
                          {night && (
                            <p className="text-[11px] text-[#A16207] italic font-medium mt-0.5">قداس ليلي</p>
                          )}
                          <div className="flex items-center gap-2 text-[11px] text-neutral-500 flex-wrap mt-1">
                            <span className="font-semibold text-[#A16207]">{a.time}</span>
                            {a.endTime && <span className="text-[10px] text-neutral-400">← {a.endTime}</span>}
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#FEF3C7] text-[#A16207] font-semibold border border-[#FDE68A]">
                              {isTomorrow ? `الغد • ${a.day}` : "اليوم"}
                            </span>
                            {a.location && (
                              <span className="flex items-center gap-1 truncate">
                                • {a.location}
                                {(() => { const s = detectSaint(a.location); return s ? <span className="text-sm">{s.emoji}</span> : null; })()}
                              </span>
                            )}
                          </div>
                          {night && (
                            <p className="text-[10px] text-neutral-400 mt-1.5">الصيام من الساعة 3:00 بعد الظهر</p>
                          )}
                        </div>

                        <ReminderButton churchId={church.id} activity={a} churchName={church.name} />
                        {isAdmin && (
                          <div className="flex items-center gap-0.5">
                            <button onClick={() => openEditDialog(a)} className="p-1.5 rounded-lg hover:bg-neutral-100 text-neutral-400 hover:text-neutral-700" aria-label="تعديل">
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button onClick={() => { removeActivity(church.id, a.id); toast({ title: "تم الحذف" }); }} className="p-1.5 rounded-lg hover:bg-red-50 text-neutral-400 hover:text-red-500" aria-label="حذف">
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </section>
          )}

          {/* ============ Group 2: جاري الآن — clean white + green accent ============ */}
          {ongoingToday.length > 0 && (
            <section className="space-y-3">
              <div className="flex items-center justify-between px-1">
                <h3 className="text-sm font-semibold text-[#047857] flex items-center gap-1.5">
                  <span className="relative flex w-2 h-2">
                    <span className="absolute inline-flex w-full h-full rounded-full bg-[#22C55E] opacity-60 animate-ping" />
                    <span className="relative inline-flex w-2 h-2 rounded-full bg-[#22C55E]" />
                  </span>
                  أنشطة اليوم
                </h3>
                <span className="text-[10px] text-neutral-400 font-semibold">{ongoingToday.length}</span>
              </div>
              <AnimatePresence initial={false}>
                {ongoingToday.map((a) => (
                  <motion.div
                    key={a.id}
                    layout
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.97 }}
                    transition={{ duration: 0.3, ease: "easeOut" }}
                    className="rounded-2xl border-r-4 border border-neutral-100"
                    style={{
                      background: isNightMass(a) ? "#FEF3C7" : "#FFFFFF",
                      borderRightColor: "#22C55E",
                      boxShadow: "0 4px 14px -6px rgba(0,0,0,0.06)",
                    }}
                  >
                    <div className="p-3.5 flex items-center gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-semibold text-[#111827] truncate flex items-center gap-1.5">
                            {isNightMass(a) && <span className="text-base leading-none">🌙</span>}
                            {a.type}
                          </p>
                          <span className="text-[10px] font-bold text-[#22C55E]">جاري الآن</span>
                        </div>
                        {isNightMass(a) && (
                          <p className="text-[11px] text-[#A16207] italic font-medium mt-0.5">قداس ليلي</p>
                        )}

                        <div className="flex items-center gap-2 text-[11px] text-neutral-500 flex-wrap mt-1">
                          <span className="font-semibold text-[#047857]">{a.time}</span>
                          {a.endTime && (
                            <span className="text-[10px] text-neutral-400">
                              <span className="italic">تقريبًا سينتهي</span> {a.endTime}
                            </span>
                          )}
                          {a.location && (
                            <span className="flex items-center gap-1 truncate">
                              • {a.location}
                              {(() => { const s = detectSaint(a.location); return s ? <span className="text-sm">{s.emoji}</span> : null; })()}
                            </span>
                          )}
                        </div>
                        {isNightMass(a) && (
                          <p className="text-[10px] text-neutral-400 mt-1.5">الصيام من الساعة 3:00 بعد الظهر</p>
                        )}
                      </div>

                      <ReminderButton churchId={church.id} activity={a} churchName={church.name} />
                      {isAdmin && (
                        <div className="flex items-center gap-0.5">
                          <button onClick={() => openEditDialog(a)} className="p-1.5 rounded-lg hover:bg-neutral-100 text-neutral-400 hover:text-neutral-700" aria-label="تعديل">
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button onClick={() => { removeActivity(church.id, a.id); toast({ title: "تم الحذف" }); }} className="p-1.5 rounded-lg hover:bg-red-50 text-neutral-400 hover:text-red-500" aria-label="حذف">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </section>
          )}

          {/* ============ Group 3: انتهت — elegant white + red ============ */}
          {endedToday.length > 0 && (
            <section className="space-y-3">
              <div className="flex items-center justify-between px-1">
                <h3 className="text-sm font-semibold flex items-center gap-1.5" style={{ color: "#B91C1C" }}>
                  <span className="text-neutral-400">✓</span>
                  الأنشطة التي انتهت
                </h3>
                <span className="text-[10px] text-neutral-400 font-semibold">{endedToday.length}</span>
              </div>
              <AnimatePresence initial={false}>
                {endedToday.map((a) => (
                  <motion.div
                    key={a.id}
                    layout
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="rounded-2xl overflow-hidden border-[1.5px]"
                    style={{
                      background: "linear-gradient(180deg, #FFFFFF 0%, #FEF2F2 100%)",
                      borderColor: "#FECACA",
                      boxShadow: "0 10px 24px -12px rgba(254,202,202,0.5), 0 2px 6px rgba(0,0,0,0.03)",
                    }}
                  >
                    <div className="h-1.5 w-full bg-gradient-to-l from-[#EF4444] to-[#DC2626]" />
                    <div className="p-3.5 flex items-center gap-3">
                      <span className="text-neutral-400 shrink-0">✓</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-[#6B7280] line-through truncate">{a.type}</p>
                        <div className="flex items-center gap-2 text-[11px] text-neutral-400 flex-wrap mt-1">
                          <span className="line-through">{a.time}</span>
                          {a.location && <span className="truncate">• {a.location}</span>}
                        </div>
                      </div>
                      {isAdmin && (
                        <button onClick={() => { removeActivity(church.id, a.id); toast({ title: "تم الحذف" }); }} className="p-1.5 rounded-lg hover:bg-red-50 text-neutral-400 hover:text-red-500" aria-label="حذف">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </section>
          )}

          {upcomingCombined.length === 0 && ongoingToday.length === 0 && (
            <p className="text-center text-xs text-neutral-400 py-6">لا توجد أنشطة متبقية لليوم 🙏</p>
          )}


          <div className="space-y-3">
            <h3 className="text-sm font-bold text-foreground">الفئات</h3>
            <div className="grid grid-cols-1 gap-2.5">
              {Array.from(categoriesMap.entries()).map(([type, acts]) => (
                <button
                  key={type}
                  onClick={() => setOpenType(type)}
                  className="bg-card rounded-2xl shadow-card hover:shadow-card-hover transition-all p-4 text-right flex items-center gap-3 group"
                >
                  <div className="w-12 h-12 rounded-xl bg-secondary/50 flex items-center justify-center text-2xl shrink-0">
                    {getCategoryIcon(type)}
                  </div>
                  <div className="flex-1">
                    <h4 className="text-sm font-bold text-foreground">{type}</h4>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      {acts.length > 0 ? `${acts.length} موعد أسبوعيًا` : "لا توجد مواعيد"}
                    </p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-accent rotate-180 transition-colors" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Weekly schedule per type */}
      <Dialog open={!!openType} onOpenChange={(o) => !o && setOpenType(null)}>
        <DialogContent dir="rtl" className="max-w-md max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-sm">
              <span>{openType && getCategoryIcon(openType)}</span>
              مواعيد {openType} — الأسبوع
            </DialogTitle>
          </DialogHeader>
          <AnimatePresence mode="wait">
            <motion.div
              key={openType || ""}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-2.5"
            >
              {DAYS.map((day) => {
                const acts = weeklyForType[day] || [];
                const isToday = day === today;
                return (
                  <div
                    key={day}
                    className={`rounded-xl overflow-hidden border ${isToday ? "border-primary/40 bg-primary/5" : "border-border/40 bg-card"}`}
                  >
                    <div className="px-3 py-1.5 border-b border-border/30 flex items-center justify-between">
                      <h4 className="text-xs font-bold text-foreground">{day}</h4>
                      <div className="flex items-center gap-1.5">
                        {isToday && (
                          <span className="text-[9px] bg-primary text-primary-foreground px-1.5 py-0.5 rounded-full font-semibold">
                            اليوم
                          </span>
                        )}
                        {isAdmin && openType && (
                          <button
                            onClick={() => openAddDialog(openType, day)}
                            className="text-[10px] flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-accent/10 text-accent hover:bg-accent/20 font-semibold"
                            aria-label="إضافة موعد لهذا اليوم"
                          >
                            <Plus className="w-3 h-3" />
                            موعد
                          </button>
                        )}
                      </div>
                    </div>
                    <div className="p-2.5">
                      {acts.length > 0 ? (
                        <div className="space-y-1.5">
                          {acts.map((a) => {
                            const ended = isToday && isActivityEnded(a, now);
                            return (
                            <div key={a.id} className="flex items-center gap-2 text-xs flex-wrap">
                              <Clock className="w-3 h-3 text-accent shrink-0" />
                              <span className={`font-bold shrink-0 ${ended ? "text-muted-foreground line-through" : "text-accent"}`}>{a.time}</span>
                              {a.endTime && (
                                <span className="inline-flex items-center gap-1 text-[9px] bg-accent/10 text-accent px-1.5 py-0.5 rounded-full font-semibold shrink-0">
                                  <span className="italic opacity-80">تقريبًا سينتهي</span>
                                  <span className="font-bold not-italic">{a.endTime}</span>
                                </span>
                              )}
                              {ended && (
                                <span className="text-[9px] font-bold text-red-600 bg-red-50 dark:bg-red-950/30 px-1.5 py-0.5 rounded-full border border-red-200 dark:border-red-900 shrink-0">
                                  قد انتهى
                                </span>
                              )}
                              {a.location && (
                                <span className="text-[10px] text-muted-foreground truncate flex items-center gap-1">
                                  • {a.location}
                                  {(() => {
                                    const s = detectSaint(a.location);
                                    return s ? <span title={s.name} className="text-sm">{s.emoji}</span> : null;
                                  })()}
                                </span>
                              )}
                              <div className="mr-auto flex items-center gap-0.5">
                                <ReminderButton churchId={church.id} activity={a} churchName={church.name} />
                                {isAdmin && (
                                  <>
                                    <button
                                      onClick={() => openEditDialog(a)}
                                      className="p-1 rounded hover:bg-secondary text-muted-foreground hover:text-foreground"
                                      aria-label="تعديل"
                                    >
                                      <Pencil className="w-3 h-3" />
                                    </button>
                                    <button
                                      onClick={() => { removeActivity(church.id, a.id); toast({ title: "تم الحذف" }); }}
                                      className="p-1 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive"
                                      aria-label="حذف"
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </button>
                                  </>
                                )}
                              </div>

                            </div>
                            );
                          })}
                        </div>
                      ) : (
                        <p className="text-center text-[11px] text-muted-foreground py-1">
                          لا توجد مواعيد 🙏
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </motion.div>
          </AnimatePresence>
        </DialogContent>
      </Dialog>

      {/* Add / Edit slot dialog */}
      <Dialog open={slotOpen} onOpenChange={setSlotOpen}>
        <DialogContent dir="rtl" className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-sm">
              {editingId ? "تعديل الموعد" : "إضافة موعد نشاط"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-[11px] text-muted-foreground mb-1 block">نوع النشاط</label>
              <Input
                placeholder="مثال: قداس، تسبحة، اجتماع شباب..."
                value={draft.type}
                onChange={(e) => setDraft({ ...draft, type: e.target.value })}
                className="rounded-xl"
              />
            </div>
            <div>
              <label className="text-[11px] text-muted-foreground mb-1 block">اليوم</label>
              <select
                value={draft.day}
                onChange={(e) => setDraft({ ...draft, day: e.target.value as DayName })}
                className="w-full bg-background border border-input rounded-xl px-3 py-2 text-sm"
                dir="rtl"
              >
                {DAYS.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className="text-[11px] text-muted-foreground mb-1 block">وقت البدء</label>
              <div className="flex gap-2">
                <Input value={draft.hours} onChange={(e) => setDraft({ ...draft, hours: e.target.value })} placeholder="ساعة" className="rounded-xl" dir="ltr" maxLength={2} />
                <Input value={draft.minutes} onChange={(e) => setDraft({ ...draft, minutes: e.target.value })} placeholder="دقيقة" className="rounded-xl" dir="ltr" maxLength={2} />
                <select
                  value={draft.period}
                  onChange={(e) => setDraft({ ...draft, period: e.target.value as "ص" | "م" })}
                  className="bg-background border border-input rounded-xl px-3 text-sm"
                >
                  <option value="ص">ص</option>
                  <option value="م">م</option>
                </select>
              </div>
            </div>
            <div className="rounded-xl border border-border/50 bg-secondary/30 p-3 space-y-2">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={draft.hasEnd}
                  onChange={(e) => setDraft({ ...draft, hasEnd: e.target.checked })}
                  className="w-4 h-4 accent-primary"
                />
                <span className="text-[12px] font-semibold text-foreground">تحديد وقت انتهاء تقريبي</span>
              </label>
              {draft.hasEnd && (
                <div className="flex gap-2">
                  <Input value={draft.endHours} onChange={(e) => setDraft({ ...draft, endHours: e.target.value })} placeholder="ساعة" className="rounded-xl" dir="ltr" maxLength={2} />
                  <Input value={draft.endMinutes} onChange={(e) => setDraft({ ...draft, endMinutes: e.target.value })} placeholder="دقيقة" className="rounded-xl" dir="ltr" maxLength={2} />
                  <select
                    value={draft.endPeriod}
                    onChange={(e) => setDraft({ ...draft, endPeriod: e.target.value as "ص" | "م" })}
                    className="bg-background border border-input rounded-xl px-3 text-sm"
                  >
                    <option value="ص">ص</option>
                    <option value="م">م</option>
                  </select>
                </div>
              )}
              <p className="text-[10px] text-muted-foreground leading-relaxed">
                سيظهر بجانب الموعد: <span className="italic">"تقريبًا سينتهي ٨:٣٠"</span>، وبعد مرور هذا الوقت ستظهر كلمة <span className="text-red-600 font-bold">"قد انتهى"</span>.
              </p>
            </div>
            <div>
              <label className="text-[11px] text-muted-foreground mb-1 block">
                اسم الكنيسة الداخلية / المكان (اختياري)
              </label>
              <Input
                placeholder="مثال: كنيسة العذراء الداخلية، قاعة الشباب..."
                value={draft.location}
                onChange={(e) => setDraft({ ...draft, location: e.target.value })}
                className="rounded-xl"
              />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleSaveSlot} className="w-full rounded-xl">
              {editingId ? "حفظ التعديلات" : "حفظ النشاط"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Media manager — admin only */}
      <Dialog open={mediaOpen} onOpenChange={setMediaOpen}>
        <DialogContent dir="rtl" className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-sm">وسائط الكنيسة</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-[11px] text-muted-foreground">صورة الكنيسة الأساسية</label>
              <div className="w-full h-32 rounded-xl overflow-hidden bg-secondary">
                <img
                  src={mediaChurchUrl || getDefaultChurchImage(church.name)}
                  alt="معاينة"
                  className="w-full h-full object-cover"
                />
              </div>
              <Input
                placeholder="رابط الصورة (اتركه فارغاً لاستخدام الافتراضية)"
                value={mediaChurchUrl}
                onChange={(e) => setMediaChurchUrl(e.target.value)}
                dir="ltr"
                className="rounded-xl"
              />
              <input
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  const reader = new FileReader();
                  reader.onload = () => setMediaChurchUrl(String(reader.result || ""));
                  reader.readAsDataURL(f);
                }}
                className="text-xs"
              />
            </div>

            {churchSaint && (
              <div className="space-y-2 pt-2 border-t border-border/40">
                <label className="text-[11px] text-muted-foreground">
                  صورة الشفيع: {churchSaint.name}
                </label>
                <div className="w-16 h-16 rounded-full overflow-hidden bg-secondary border border-border/40 flex items-center justify-center text-2xl">
                  {mediaSaintUrl ? (
                    <img src={mediaSaintUrl} alt={churchSaint.name} className="w-full h-full object-cover" />
                  ) : (
                    <span>{churchSaint.emoji}</span>
                  )}
                </div>
                <Input
                  placeholder="رابط صورة الشفيع (اختياري)"
                  value={mediaSaintUrl}
                  onChange={(e) => setMediaSaintUrl(e.target.value)}
                  dir="ltr"
                  className="rounded-xl"
                />
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    const reader = new FileReader();
                    reader.onload = () => setMediaSaintUrl(String(reader.result || ""));
                    reader.readAsDataURL(f);
                  }}
                  className="text-xs"
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              onClick={() => {
                updateChurch(church.id, { imageUrl: mediaChurchUrl.trim() });
                if (churchSaint) setSaintOverride(church.id, mediaSaintUrl.trim());
                toast({ title: "تم حفظ الوسائط ✝️" });
                setMediaOpen(false);
              }}
              className="w-full rounded-xl"
            >
              حفظ
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ChurchDetail;
