import { useState, useMemo, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, Heart, MapPin, ChevronLeft, Star, HandHeart } from "lucide-react";
import { Input } from "@/components/ui/input";
import { GOVERNORATES } from "@/types/church";
import { useChurchStore } from "@/hooks/useChurchStore";
import { setAdminSession, isAdminSession, clearSession } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import RequestActivityDialog from "@/components/RequestActivityDialog";

const Index = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { churches: allChurches } = useChurchStore();
  const [search, setSearch] = useState("");
  const [requestOpen, setRequestOpen] = useState(false);


  // Hidden admin trigger: 7 taps on title toggles admin mode
  const tapCountRef = useRef(0);
  const tapTimerRef = useRef<number | null>(null);

  const handleTitleTap = () => {
    tapCountRef.current += 1;
    if (tapTimerRef.current) window.clearTimeout(tapTimerRef.current);
    tapTimerRef.current = window.setTimeout(() => {
      tapCountRef.current = 0;
    }, 1500);
    if (tapCountRef.current >= 7) {
      tapCountRef.current = 0;
      if (isAdminSession()) {
        clearSession();
        toast({ title: "تم الخروج من وضع الأدمن" });
      } else {
        setAdminSession("hidden");
        toast({ title: "مرحبًا بالأدمن ✝️" });
        navigate("/admin");
      }
    }
  };

  const governoratesWithCount = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const c of allChurches) {
      counts[c.governorate] = (counts[c.governorate] || 0) + 1;
    }
    return GOVERNORATES.map((g) => ({ name: g, count: counts[g] || 0 }));
  }, [allChurches]);

  const filtered = search
    ? governoratesWithCount.filter((g) => g.name.includes(search))
    : governoratesWithCount;

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-card/90 backdrop-blur-lg border-b border-border/40">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center shrink-0">
            <span className="text-lg text-primary-foreground">✝</span>
          </div>
          <button
            onClick={handleTitleTap}
            className="flex-1 text-right select-none"
            aria-label="title"
          >
            <h1 className="text-base font-bold text-foreground">دليل كنائس مصر</h1>
            <p className="text-[10px] text-muted-foreground">أنشطة ومواعيد الكنائس</p>
          </button>
          <button
            onClick={() => navigate("/favorites")}
            className="p-2 rounded-lg hover:bg-secondary transition-colors"
            aria-label="favorites"
          >
            <Star className="w-5 h-5 text-accent" />
          </button>
          <button
            onClick={() => navigate("/donations")}
            className="p-2 rounded-lg hover:bg-secondary transition-colors"
            aria-label="donations"
          >
            <Heart className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-5 space-y-5">
        {/* Request activity CTA */}
        <motion.button
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          onClick={() => setRequestOpen(true)}
          className="w-full rounded-2xl px-4 py-3.5 flex items-center justify-between bg-gradient-to-l from-accent to-primary text-primary-foreground shadow-card-hover active:scale-[0.99] transition-transform"
        >
          <ChevronLeft className="w-4 h-4 opacity-80" />
          <span className="flex items-center gap-2 font-bold text-sm">
            <HandHeart className="w-5 h-5" />
            اطلب نشاط لكنيستك 🙏
          </span>
        </motion.button>

        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-3"
        >
          <p className="text-base font-semibold text-foreground leading-relaxed">
            "اَلرَّبُّ قَرِيبٌ لِكُلِّ الَّذِينَ يَدْعُونَهُ" 🙏
          </p>
          <div className="w-16 h-0.5 bg-accent/40 mx-auto mt-3 rounded-full" />
        </motion.div>


        {/* Search */}
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="ابحث عن محافظة..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-9 bg-card border-border/50 rounded-xl h-11 text-sm"
          />
        </div>

        {/* Governorates Grid */}
        <div className="space-y-3">
          <h2 className="text-sm font-bold text-foreground px-1">اختر المحافظة</h2>
          <div className="grid grid-cols-2 gap-2.5">
            {filtered.map((gov, i) => (
              <motion.button
                key={gov.name}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.02, 0.3) }}
                onClick={() => navigate(`/governorate/${encodeURIComponent(gov.name)}`)}
                className="bg-card rounded-xl p-3 shadow-card hover:shadow-card-hover transition-all text-right group"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <ChevronLeft className="w-3.5 h-3.5 text-muted-foreground group-hover:text-accent transition-colors" />
                  <MapPin className="w-4 h-4 text-accent" />
                </div>
                <h3 className="text-xs font-bold text-foreground">{gov.name}</h3>
                <p className="text-[10px] text-muted-foreground">
                  {gov.count > 0 ? `${gov.count} كنيسة` : "قريبًا"}
                </p>
              </motion.button>
            ))}
          </div>

          {filtered.length === 0 && (
            <p className="text-center text-xs text-muted-foreground py-6">لا توجد نتائج</p>
          )}
        </div>
      </main>

      <RequestActivityDialog open={requestOpen} onOpenChange={setRequestOpen} />
    </div>

  );
};

export default Index;
